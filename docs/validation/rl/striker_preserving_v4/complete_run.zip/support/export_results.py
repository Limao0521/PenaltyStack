"""Package the completed preserving experiment after explicit root authorization.

Reads only immutable experiment evidence. No trainer, simulator or Torch is
imported; no physical seeds are consumed. Use --export --fingerprint HASH only
after the complete independent final audit is available and root authorizes it.
"""
from collections import Counter
import argparse
from copy import deepcopy
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shutil
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

import numpy as np


ROOT = Path(__file__).resolve().parents[2]
SUPPORT_ROOT = ROOT/'runs/striker_retrain_v2'
RUN = SUPPORT_ROOT/'preserving_v4'
MODEL = ROOT/'models/rl/striker_preserving_v4'
REPORT = ROOT/'docs/validation/rl/striker_preserving_v4'
POLICY_FILES = ('model.zip', 'obs_norm.npz', 'config.json')
RESULTS = ('goal', 'save', 'miss', 'striker_fall', 'keeper_fall', 'timeout', 'sim_error')
CHECKPOINT_VERSION = 'striker_visual_checkpoint_v2'
TEST_NAMES = {'balanced': 'Nuestro portero v2 visual + balanced, movimiento original',
              'motion': 'Nuestro portero v2 visual + balanced + salto ajustado',
              'scripted': 'Nuestra FSM base con movimientos B-Human'}


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode('utf-8')


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    def invalid(value):
        raise ValueError('nonfinite JSON: '+value)
    return json.loads(Path(path).read_text(encoding='utf-8'), parse_constant=invalid)


def json_bytes(value):
    return (json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False)+'\n').encode('utf-8')


def atomic_write(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name+'.tmp-'+str(os.getpid()))
    try:
        temporary.write_bytes(data)
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def immutable_copy(source, target):
    source, target = Path(source), Path(target)
    if target.exists():
        if target.read_bytes() != source.read_bytes():
            raise ValueError('refusing to replace different exported bytes: '+str(target))
        return
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
    if sha(source) != sha(target):
        raise ValueError('copy checksum mismatch')


def envelope(path, fingerprint):
    data = read(path)
    if (data.get('version') != CHECKPOINT_VERSION or data.get('fingerprint') != fingerprint or
            data.get('payload_sha256') != digest(data.get('payload'))):
        raise ValueError('checkpoint envelope differs: '+str(path))
    return data['payload']


def policy_hashes(directory):
    return {name: sha(Path(directory)/name) for name in POLICY_FILES}


def physical_reset(record):
    data = record['reset_info']
    return {name: data[name] for name in ('engine_seed', 'ball_xy', 'start_offsets')}


def summary(records):
    if not records or any(row['result'] not in RESULTS for row in records):
        raise ValueError('empty or invalid episode records')
    counts = Counter(row['result'] for row in records)
    return {'episodes': len(records), 'counts': {name: counts[name] for name in RESULTS},
            'goal_rate': counts['goal']/len(records), 'save_rate': counts['save']/len(records)}


def verify_summary(rows, published):
    measured = summary(rows)
    if (published['episodes'] != measured['episodes'] or
            published['goal_rate'] != measured['goal_rate'] or
            published['save_rate'] != measured['save_rate'] or
            {key: published['counts'].get(key, 0) for key in RESULTS} != measured['counts'] or
            measured['counts']['sim_error']):
        raise ValueError('evaluation counts/rates/error status differ')
    return measured


def paired_comparison(candidate, baseline):
    a, b = ({row['seed']: row for row in rows} for rows in (candidate, baseline))
    if not a or len(a) != len(candidate) or len(b) != len(baseline) or set(a) != set(b):
        raise ValueError('paired comparison requires equal unique physical seeds')
    seeds = sorted(a)
    for seed in seeds:
        if physical_reset(a[seed]) != physical_reset(b[seed]):
            raise ValueError('paired physical starts differ')
    differences = np.array([int(a[seed]['result'] == 'goal')-int(b[seed]['result'] == 'goal')
                            for seed in seeds])
    bootstrap = np.random.default_rng(101001).choice(differences, (10000, len(seeds)), replace=True).mean(axis=1)
    return {'episodes': len(seeds), 'goal_gain': float(differences.mean()),
            'goal_gain_ci95': np.quantile(bootstrap, [.025, .975]).tolist(),
            'candidate_only_goals': int((differences == 1).sum()),
            'baseline_only_goals': int((differences == -1).sum())}


def checked_inputs(manifest):
    expected = manifest['configuration']['source_hashes']
    dll = 'native/bhuman_motion/build/vision/Release/onnxruntime.dll'
    if dll not in expected or len(expected) < 120:
        raise ValueError('complete frozen preserving inputs and detector DLL required')
    result = []
    for relative, checksum in sorted(expected.items()):
        path = (ROOT/relative).resolve()
        if not path.is_relative_to(ROOT.resolve()) or sha(path) != checksum:
            raise ValueError('frozen source/input bytes changed: '+relative)
        result.append({'path': path, 'archive': 'inputs/'+relative.replace('\\', '/'),
                       'sha256': checksum, 'bytes': path.stat().st_size, 'role': 'frozen_input'})
    return result


def verify_evaluation(report, configuration, split, policies, modes):
    count = configuration[split+'_episodes']
    seeds = {configuration['split_bases'][split]*1_000_000+i for i in range(count)}
    if (report['split'] != split or set(report['records']) != set(modes) or
            report['identity']['split'] != split or
            report['identity']['policies'] != {name: policy_hashes(path) for name, path in policies.items()} or
            report['fingerprint'] != digest(report['identity'])):
        raise ValueError('evaluation frozen identity differs')
    for mode, peers in report['records'].items():
        if set(peers) != set(policies):
            raise ValueError('evaluation policy set differs')
        for name, rows in peers.items():
            if len(rows) != count or {row['seed'] for row in rows} != seeds:
                raise ValueError('evaluation namespace/count differs')
            verify_summary(rows, report['summaries'][mode][name])
            if any(row['environment']['keeper_mode'] != mode for row in rows):
                raise ValueError('opponent provenance differs')
        for name in set(policies)-{'v2'}:
            paired_comparison(peers[name], peers['v2'])
    if len(report['rows']) != count*len(modes):
        raise ValueError('physical case count differs')
    tag = 'validation_selection' if split == 'validation' else 'blind_test'
    seen = set()
    for row in report['rows']:
        key = (row['keeper_mode'], row['seed'])
        if (key in seen or row['seed'] not in seeds or row['keeper_mode'] not in modes or
                row.get('children_collected') is not True or row.get('owned_native_children', 0) < 1 or
                set(row['records']) != set(policies)):
            raise ValueError('physical case identity/cleanup differs')
        seen.add(key)
        cached = envelope(RUN/'evaluations'/tag/(row['keeper_mode']+'-'+str(row['seed'])+'.json'),
                          report['fingerprint'])
        if cached != row:
            raise ValueError('cache envelope and report differ')
        for name, record in row['records'].items():
            grouped = next(item for item in report['records'][row['keeper_mode']][name]
                           if item['seed'] == row['seed'])
            if record != grouped:
                raise ValueError('cache record and grouped report differ')


def recommendation(selected, test, configuration):
    """Preregistered recommendation only; never chooses or changes model weights."""
    primary = test['comparisons']['balanced']
    retention = test['comparisons']['scripted']
    baseline = next(item for item in selected['candidates'] if item['update'] == 0)
    conditions = {
        # The selector also breaks equal goal rates by falls. Promotion requires
        # a strictly better goal rate, so its boolean alone is insufficient.
        'validation_primary_strictly_better_than_v2':
            selected['validation_summary']['goal_rate'] > baseline['summary']['goal_rate'],
        'validation_observed_fsm_retention_gate': selected['retention_gate_satisfied'],
        'blind_primary_paired_ci95_lower_gt_zero': primary['goal_gain_ci95'][0] > 0.,
        'blind_observed_fsm_gain_at_least_minus_max_drop':
            retention['goal_gain']+1e-12 >= -configuration['retention_max_drop'],
    }
    promoted = all(conditions.values()) and not selected['diagnostic_only']
    return {'promoted': promoted, 'conditions': conditions,
            'recommended_reference': 'models/rl/striker_preserving_v4' if promoted else 'models/rl/striker_v2',
            'test_changes_recommendation_only': True, 'test_selects_or_fits_weights': False,
            'retention_gate_is_formal_noninferiority_test': False}


def validate_completed_run(expected_fingerprint):
    manifest = read(RUN/'run_manifest.json')
    fingerprint, config = manifest['fingerprint'], manifest['configuration']
    if fingerprint != expected_fingerprint or digest(config) != fingerprint:
        raise ValueError('authorized run manifest identity/configuration differs')
    if (manifest.get('test_protocol_fixed_before_training') is not True or
            config['training'] != 'striker_visual_retraining_v2' or
            config['primary_keeper'] != 'vision_keeper_v2:balanced:original_motion' or
            config['reward'] != 'striker_visual_reward_v3' or
            config['initialization'] != 'striker_policy_init_v3' or
            config['actor_weights_preserved_initially'] is not True or config['head_rows_rescaled'] is not False or
            config['action_mean_tail_compression'] != {'threshold': 1., 'slope': .01, 'deterministic_postclip_identity': True} or
            config['test_may_select_or_fit'] is not False or config['async_training_compatible'] is not False or
            config['training_opponents_by_worker'] != ['balanced']*5+['scripted'] or
            (config['workers'], config['updates'], config['ppo']['n_steps'], config['checkpoint_every'],
             config['validation_episodes'], config['test_episodes']) != (6, 96, 128, 32, 64, 100) or
            config['ppo']['gamma'] != 1. or config['retention_max_drop'] != .10 or
            config['promotion_rule'] != {'validation_primary_goal_rate_strictly_above_v2': True,
                                         'validation_fsm_point_drop_at_most': .10,
                                         'blind_primary_paired_ci95_lower_strictly_above_zero': True,
                                         'blind_fsm_point_drop_at_most': .10,
                                         'retention_is_formal_noninferiority_test': False} or
            config['split_bases'] != {'train': 101001, 'validation': 102001, 'test': 103001} or
            config['validation_opponents'] != ['balanced', 'scripted'] or
            config['test_opponents'] != ['balanced', 'motion', 'scripted']):
        raise ValueError('the preregistered preserving experiment scope differs')
    inputs = checked_inputs(manifest)
    if (policy_hashes(RUN/'frozen/striker_v2') != config['base_policy_sha256'] or
            policy_hashes(ROOT/'models/rl/striker_v2') != config['base_policy_sha256'] or
            sha(RUN/'frozen/keeper_motion_v1.json') != config['motion_model_sha256']):
        raise ValueError('base policy or frozen opponent bytes changed')
    state = envelope(RUN/'progress.json', fingerprint)
    training = read(RUN/'training_report.json')
    if (state['completed_updates'] != 96 or state['training_transitions'] != 73728 or
            state.get('failure_status') or state.get('inflight_rollout') or
            training['fingerprint'] != fingerprint or training['state'] != state or
            training['convergence_established'] is not False):
        raise ValueError('complete clean optimizer budget/report required')
    if summary(state['episode_records'])['counts']['sim_error']:
        raise ValueError('a failed physical episode was incorporated into optimized training records')
    updates = {int(path.name.removeprefix('update_')) for path in (RUN/'checkpoints').glob('update_*')
               if path.is_dir() and '.tmp' not in path.name}
    if updates != set(range(1, 97)):
        raise ValueError('96 complete optimizer checkpoints required')
    for update in sorted(updates):
        directory = RUN/'checkpoints'/('update_%04d' % update)
        resume = envelope(directory/'resume_state.json', fingerprint)
        if (resume['completed_updates'] != update or resume['training_transitions'] != update*768 or
                resume['checkpoint'] != directory.relative_to(RUN).as_posix() or
                resume['checkpoint_sha256'] != policy_hashes(directory) or
                set(resume.get('rng', {})) != {'python', 'numpy', 'torch'} or
                sha(directory/'obs_norm.npz') != config['base_policy_sha256']['obs_norm.npz']):
            raise ValueError('checkpoint resume/RNG/statistics differ')
        with ZipFile(directory/'model.zip') as model_zip:
            if not {'policy.pth', 'policy.optimizer.pth', 'data'} <= set(model_zip.namelist()):
                raise ValueError('PPO optimizer/model entries missing')
    initialization = read(RUN/'initialization_report.json')
    proof = initialization['proof']
    if (initialization['version'] != 'striker_policy_init_v3' or
            initialization['fingerprint'] != fingerprint or
            initialization['policy_sha256'] != policy_hashes(RUN/'initialized') or
            initialization['normalization_sha256'] != config['base_policy_sha256']['obs_norm.npz'] or
            proof['actor_parameters_byte_identical'] is not True or
            proof['base_actor_sha256'] != proof['initialized_actor_sha256'] or
            proof['base_model_sha256'] != config['base_policy_sha256']['model.zip'] or
            proof['action_head_rescaled'] is not False or proof['tail_slope'] != .01 or
            proof['optimizer_reset'] != 'complete' or proof['optimizer_initial_state_entries'] != 0 or
            proof['value_head_zeroed'] is not True or proof['gamma'] != 1. or proof['initial_std'] != .25 or
            proof['straight_through_gradient'] is not False):
        raise ValueError('actor-preserving initialization evidence differs')
    selected = envelope(RUN/'selection.json', fingerprint)
    validation_path = RUN/'evaluations/validation_selection/report.json'
    validation = read(validation_path)
    policies = {'v2': RUN/'frozen/striker_v2', 'initialized': RUN/'initialized',
                **{'update_%04d' % update: RUN/'checkpoints'/('update_%04d' % update) for update in (32, 64, 96)}}
    verify_evaluation(validation, config, 'validation', policies, ('balanced', 'scripted'))
    if (selected['test_used_for_selection'] is not False or selected['update'] not in (32, 64, 96) or
            selected['policy'] != 'checkpoints/update_%04d' % selected['update'] or
            selected['policy_sha256'] != policy_hashes(RUN/selected['policy']) or
            selected['validation_report_sha256'] != sha(validation_path) or
            selected['retention_gate_is_formal_noninferiority_test'] is not False):
        raise ValueError('validation-only frozen selection differs')
    candidates = selected['candidates']
    baseline = next(item for item in candidates if item['update'] == 0)
    trained = [item for item in candidates if item['update'] > 0]
    if {item['update'] for item in trained} != {32, 64, 96}:
        raise ValueError('preregistered validation candidate set differs')
    for item in candidates:
        name = 'v2' if item['update'] == 0 else 'update_%04d' % item['update']
        if (item['summary'] != validation['summaries']['balanced'][name] or
                item['retention_summary'] != validation['summaries']['scripted'][name] or
                item['policy_sha256'] != policy_hashes(RUN/item['policy'])):
            raise ValueError('candidate validation record/weights differ')
    eligible = [item for item in trained if item['retention_summary']['goal_rate']+1e-12 >=
                baseline['retention_summary']['goal_rate']-.10]
    order = lambda item: (-item['summary']['goal_rate'], item['summary']['striker_fall_rate'], item['update'])
    chosen = min(eligible or trained, key=order)
    promotion = min([baseline, *eligible], key=order)
    if (chosen['update'] != selected['update'] or selected['validation_summary'] != chosen['summary'] or
            selected['retention_summary'] != chosen['retention_summary'] or
            selected['retention_gate_satisfied'] != bool(eligible) or selected['diagnostic_only'] != (not bool(eligible)) or
            selected['promotion_candidate'] != promotion or
            selected['validation_prefers_trained_over_v2'] != (promotion['update'] > 0)):
        raise ValueError('selection differs from predeclared primary/retention rule')
    test = read(RUN/'test_report.json')
    if (test['run_fingerprint'] != fingerprint or test['selection_sha256'] != sha(RUN/'selection.json') or
            test['policy_sha256'] != selected['policy_sha256'] or test['selected_update'] != selected['update'] or
            test['model_frozen_before_test'] is not True or test['test_used_for_selection'] is not False or
            test['hardware_validated'] is not False):
        raise ValueError('blind-test freezing evidence differs')
    verify_evaluation(test, config, 'test', {'v2': RUN/'frozen/striker_v2', 'selected': RUN/selected['policy']},
                      ('balanced', 'motion', 'scripted'))
    for mode, peers in test['records'].items():
        calculated = paired_comparison(peers['selected'], peers['v2'])
        published = test['comparisons'][mode]
        if any(published[key] != value for key, value in calculated.items()):
            raise ValueError('blind bootstrap/gains differ')
    rec = recommendation(selected, test, config)
    audit = read(RUN/'final_audit.json')
    if (audit.get('phase') != 'training, validation and blind evaluation complete' or
            audit.get('evaluation_complete') is not True or audit.get('run_fingerprint') != fingerprint or
            audit.get('test_report_sha256') != sha(RUN/'test_report.json') or
            audit.get('selection_sha256') != sha(RUN/'selection.json') or
            audit.get('source_files_verified_unchanged') != len(inputs) or
            audit.get('baseline_bhuman_files_verified_unchanged') != 559 or
            audit.get('test', {}).get('physical_cases') != 300 or
            audit.get('test', {}).get('policy_duels') != 600 or
            audit.get('conclusion', {}).get('promote_retrained_policy') != rec['promoted']):
        raise ValueError('complete independent final audit missing or inconsistent')
    full_tests = (SUPPORT_ROOT/'full_tests.log').read_text(encoding='utf-8')
    matched = re.search(r'Ran (\d+) tests in .*?\r?\n\r?\nOK', full_tests)
    if not matched or int(matched.group(1)) < 346:
        raise ValueError('complete test-suite success evidence missing')
    parity = read(SUPPORT_ROOT/'env_preservation.json')
    if (parity['version'] != 'preserving_initialization_physical_parity_v1' or
            parity['outside_train_validation_test'] is not True or
            parity['baseline_sha256'] != config['base_policy_sha256'] or len(parity['cases']) != 2 or
            any(row['physical_fields_exact'] is not True or
                set(row['children_collected']) != {'v2', 'initialized'} or
                not all(row['children_collected'].values()) for row in parity['cases'])):
        raise ValueError('four-duel physical initialization parity evidence differs')
    failures = []
    if (RUN/'failures.jsonl').exists():
        failures = [json.loads(line) for line in (RUN/'failures.jsonl').read_text(encoding='utf-8').splitlines()
                    if line.strip()]
        if any(not isinstance(row, dict) or not row.get('phase') for row in failures):
            raise ValueError('invalid durable failure diagnostics')
    return manifest, state, selected, validation, test, inputs, rec, failures, int(matched.group(1))


def archive_entries(inputs):
    entries = list(inputs)
    for path in sorted(RUN.rglob('*')):
        if path.is_file() and not any('.tmp' in part for part in path.relative_to(RUN).parts):
            entries.append({'path': path, 'archive': 'run/'+path.relative_to(RUN).as_posix(),
                            'sha256': sha(path), 'bytes': path.stat().st_size, 'role': 'complete_final_run'})
    for path in sorted(SUPPORT_ROOT.iterdir()):
        if (path.is_file() and path.suffix in ('.json', '.jsonl', '.log', '.csv', '.py', '.txt') and
                '.tmp' not in path.name and path.name != 'export_results.log'):
            entries.append({'path': path, 'archive': 'support/'+path.name,
                            'sha256': sha(path), 'bytes': path.stat().st_size, 'role': 'supporting_evidence'})
        elif path.is_dir() and path not in (RUN, SUPPORT_ROOT/'__pycache__'):
            for artifact in sorted(path.rglob('*')):
                if artifact.is_file() and not any('.tmp' in part or part == '__pycache__'
                                                 for part in artifact.relative_to(SUPPORT_ROOT).parts):
                    entries.append({'path': artifact,
                                    'archive': 'support/'+artifact.relative_to(SUPPORT_ROOT).as_posix(),
                                    'sha256': sha(artifact), 'bytes': artifact.stat().st_size,
                                    'role': 'separate_preflight_or_smoke_evidence'})
    # Tests are an export-time support snapshot when not part of the original
    # frozen training hash list; do not falsely include them in that fingerprint.
    for path in sorted((ROOT/'tests').glob('test_striker_*v2.py'))+[
            ROOT/'tests/test_striker_preserving_policy.py']:
        relative = path.relative_to(ROOT).as_posix()
        if path.exists() and not any(entry['archive'] == 'inputs/'+relative for entry in entries):
            entries.append({'path': path, 'archive': 'support/tests/'+path.name,
                            'sha256': sha(path), 'bytes': path.stat().st_size, 'role': 'export_time_test_snapshot'})
    if len({entry['archive'] for entry in entries}) != len(entries):
        raise ValueError('duplicate archive paths')
    return sorted(entries, key=lambda entry: entry['archive'])


def make_zip(entries, manifest, selected):
    package = REPORT/'complete_run.zip'
    temporary = package.with_name(package.name+'.tmp-'+str(os.getpid()))
    package_manifest = {'version': 'striker_preserving_reproducibility_bundle_v1',
                        'run_fingerprint': manifest['fingerprint'], 'selection_sha256': sha(RUN/'selection.json'),
                        'selected_policy_sha256': selected['policy_sha256'],
                        'frozen_input_count': len(manifest['configuration']['source_hashes']),
                        'onnxruntime_dll_in_original_run_fingerprint': True,
                        'contains_entire_final_run': True, 'fixed_zip_timestamp': '1980-01-01T00:00:00',
                        'files': [{key: entry[key] for key in ('archive', 'sha256', 'bytes', 'role')} for entry in entries]}
    def add(archive, payload):
        info = ZipInfo(archive, date_time=(1980, 1, 1, 0, 0, 0))
        info.compress_type = ZIP_DEFLATED
        info.create_system = 3
        info.external_attr = 0o100644 << 16
        zip_file.writestr(info, payload, compress_type=ZIP_DEFLATED, compresslevel=9)
    REPORT.mkdir(parents=True, exist_ok=True)
    try:
        with ZipFile(temporary, 'w') as zip_file:
            for entry in entries:
                payload = entry['path'].read_bytes()
                if hashlib.sha256(payload).hexdigest() != entry['sha256']:
                    raise ValueError('artifact changed during export: '+str(entry['path']))
                add(entry['archive'], payload)
            add('artifact_manifest.json', json_bytes(package_manifest))
        with ZipFile(temporary) as zip_file:
            if zip_file.testzip() is not None:
                raise ValueError('archive CRC failure')
            for entry in entries:
                if hashlib.sha256(zip_file.read(entry['archive'])).hexdigest() != entry['sha256']:
                    raise ValueError('archive SHA mismatch')
        if package.exists() and sha(package) != sha(temporary):
            raise ValueError('existing archive differs from the finalized evidence')
        os.replace(temporary, package)
    finally:
        if temporary.exists():
            temporary.unlink()
    return package_manifest, sha(package)


def pct(value):
    return ('%.2f' % (100*value)).replace('.', ',')+' %'


def pp(value):
    return ('%+.2f' % (100*value)).replace('.', ',')


def make_readme(manifest, state, selected, validation, test, package_sha, rec, failures, full_test_count):
    config = manifest['configuration']
    conclusion = ('El candidato cumple los criterios predeclarados de mejora y pasa a ser la referencia recomendada para estos rivales en simulación.'
                  if rec['promoted'] else
                  'El candidato no cumple todos los criterios predeclarados de mejora. Se conserva striker_v2 como tirador recomendado y este modelo queda experimental.')
    table = ['| Portero | Tirador | Penales | Goles | Atajadas | Fuera/corto | Timeout | Caída terminal |',
             '| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |']
    gains = ['| Portero | Cambio de goles frente a v2 | IC95 pareado | Goles exclusivos nuevo / v2 |',
             '| --- | ---: | --- | ---: |']
    for mode in config['test_opponents']:
        for name in ('v2', 'selected'):
            rows = test['records'][mode][name]
            counts = Counter(row['result'] for row in rows)
            table.append('| %s | %s | %d | %d (%s) | %d (%s) | %d | %d | %d |' % (
                TEST_NAMES[mode], 'v2 intacto' if name == 'v2' else 'preserving_v4', len(rows),
                counts['goal'], pct(counts['goal']/len(rows)), counts['save'], pct(counts['save']/len(rows)),
                counts['miss'], counts['timeout'], counts['striker_fall']+counts['keeper_fall']))
        comparison = test['comparisons'][mode]
        lo, hi = comparison['goal_gain_ci95']
        gains.append('| %s | %s puntos | [%s; %s] puntos | %d / %d |' % (
            TEST_NAMES[mode], pp(comparison['goal_gain']), pp(lo), pp(hi),
            comparison['candidate_only_goals'], comparison['baseline_only_goals']))
    val_table = ['| Portero de validación | Política | Goles / 64 | Atajadas | Fallados | Timeout |',
                 '| --- | --- | ---: | ---: | ---: | ---: |']
    for mode in config['validation_opponents']:
        for name, rows in validation['records'][mode].items():
            counts = Counter(row['result'] for row in rows)
            val_table.append('| %s | %s | %d / %d | %d | %d | %d |' % (
                TEST_NAMES[mode], name, counts['goal'], len(rows), counts['save'], counts['miss'], counts['timeout']))
    gate_table = ['| Criterio de recomendación | Cumplido |', '| --- | --- |']
    labels = {'validation_primary_strictly_better_than_v2': 'Más goles que v2 en validación contra balanced',
              'validation_observed_fsm_retention_gate': 'Pérdida observada contra FSM ≤10 puntos en validación',
              'blind_primary_paired_ci95_lower_gt_zero': 'Límite inferior del IC95 pareado contra balanced >0',
              'blind_observed_fsm_gain_at_least_minus_max_drop': 'Pérdida observada contra FSM ≤10 puntos en prueba'}
    for key, value in rec['conditions'].items():
        gate_table.append('| %s | %s |' % (labels[key], 'Sí' if value else 'No'))
    reservations = state.get('discarded_rollout_reservations', [])
    failure_text = ('No se registró ninguna interrupción ni descarte de rollout en la corrida final.'
                    if not failures and not reservations else
                    'Entradas de diagnóstico en el registro durable: %d. Reservas de rollouts descartados en el progreso: %d. Una misma incidencia puede generar entradas de worker, callback y proceso padre: no se cuentan como incidencias independientes. Los detalles y las semillas están preservados.' % (len(failures), len(reservations)))
    training_counts = Counter(row['result'] for row in state['episode_records'])
    return '''# Tirador preserving_v4 contra nuestro portero v2 balanced

%(conclusion)s El checkpoint de la actualización **%(update)d** se eligió con validación antes de ejecutar **600 penales reservados**. La prueba sólo decide la recomendación: no eligió ni modificó pesos.

## Prueba reservada: 100 penales por portero y tirador

%(table)s

Cada pareja usa la misma semilla física y los mismos inicios dentro de su rival. Sólo `goal` cuenta como éxito; una atajada, fallo, caída terminal o timeout no cuenta como gol. `miss` es un tiro fuera/corto sin bloqueo. Una caída posterior a la patada se conserva en la traza aunque el balón termine en gol o atajada. Hubo cero `sim_error` en validación y prueba, y todos los hijos nativos fueron recogidos.

%(gains)s

Los intervalos usan 10.000 remuestreos de las parejas y todos los penales programados. La comprobación contra FSM exige una pérdida observada de como máximo 10 puntos; **no es una prueba formal de no inferioridad**. Los intervalos de rivales secundarios son descriptivos, sin corrección por comparaciones múltiples.

%(gate_table)s

## Qué se cambió al entrenar

Se completaron 96 actualizaciones PPO × 6 actores × 128 pasos: **73.728 transiciones nuevas optimizadas** y %(training_episodes)d episodios completos incorporados. Sus resultados de entrenamiento fueron %(training_goals)d goles, %(training_saves)d atajadas, %(training_misses)d fallos, %(training_timeouts)d timeout y %(training_falls)d caídas terminales. El modelo seleccionado contiene %(selected_transitions)d transiciones nuevas, correspondientes a sus primeras %(update)d actualizaciones. Es una corrida acotada; no se afirma convergencia.

La nueva inicialización `striker_policy_init_v3` conserva **cada byte de los pesos del actor v2** y su normalización. No reescala la cabeza de acciones. En entrenamiento, si una media cruda supera +1 se sustituye por `1 + 0,01*(media-1)`; si está por debajo de −1, por `−1 + 0,01*(media+1)`. Dentro de `[-1,1]` no cambia. El recorte determinista sigue produciendo exactamente las acciones de v2. Las derivadas son las reales de esa función, sin gradiente sustituto.

Se reinicia Adam completo, se pone en cero la capa final del crítico y se inicia sigma en 0,25, acotada después a [0,12; 0,40]. La recompensa nueva `striker_visual_reward_v3` da cero por paso, +1 por gol y −1 por cualquier otro terminal físico. Con `gamma=1` y el horizonte observado de 28 segundos, su retorno esperado es `2*P(gol)-1`. Un error de simulación es diagnóstico fatal: el rollout se descarta antes de optimizarlo.

Cinco de los seis actores entrenan contra nuestro portero visual v2 balanced, con movimientos originales; uno juega contra nuestra FSM base para conservar esa habilidad. PPO usa learning rate 0,00003, clip 0,05, cuatro épocas por actualización, GAE 0,95, KL objetivo 0,01 y ningún bonus de entropía. El rival con salto ajustado participa sólo en prueba.

## Selección mediante validación

%(val_table)s

Se compararon las actualizaciones 32, 64 y 96 usando 64 parejas contra balanced y otras 64 contra FSM. Entre los checkpoints entrenados que cumplen el límite de pérdida de 10 puntos frente a FSM, se elige el que obtiene más goles contra balanced; desempata con menos caídas y después con la actualización más temprana. Si ninguno cumple, se exporta el mejor entrenado sólo para diagnóstico y v2 conserva la recomendación. La política inicializada es un diagnóstico, nunca un candidato entrenado.

## Fallos, semillas y reanudación

%(failure_text)s La evidencia completa incluye `failures.jsonl` si hubo incidencias, stdout/stderr, trazas y metadatos de semillas. Antes de cada rollout se guarda un intervalo conservador de posibles semillas, de forma que una interrupción no reutilice ninguna al reanudar. Los checkpoints incluyen Adam y RNG de Python/NumPy/Torch; los episodios físicos reinician con semillas nuevas, sin simular una restauración exacta de MuJoCo. Las 73.728 transiciones son las optimizadas: no se presentan como todo el trabajo físico de un rollout descartado.

Antes de la corrida, el primer helper de paridad falló al guardar una configuración porque repetía el campo `history`. Ese error de código ocurrió antes de ejecutar los duelos de comprobación, se corrigió en el helper y se conserva su log. La repetición completó cuatro duelos, con resultados y campos físicos idénticos entre v2 y la política inicializada. El smoke test posterior completó 64 transiciones, sin episodios terminados ni error; no se presenta como una evaluación de rendimiento. Estos ensayos están separados del entrenamiento final.

Entrenamiento, validación y prueba usan respectivamente bases 101001, 102001 y 103001; la semilla física es `base*1.000.000+índice`. La selección congelada impide seguir entrenando dentro de esta corrida.

## Percepción y compatibilidad

El portero recibe RGB renderizado y sensores propios simulados de encoders/IMU/FSR, con odometría estimada. Conserva v2 balanced y no recibe orientación ideal del rival. El tirador recibe todavía `rl_obs_v1` privilegiada de la escena con `PerceptionNoise v1`, igual que v2: no es un tirador guiado por cámaras reales. La FSM rival es nuestra implementación con motores B-Human, no el equipo oficial completo de B-Human.

Las cuatro acciones son objetivo lateral, pie, potencia y disparo. B-Human sigue ejecutando los movimientos; no se entrenaron trayectorias articulares. MuJoCo usa raíces libres, servos y contactos, con sensores propios ideales y pausa física durante inferencia RGB. No se ejecutó ni validó un NAO físico.

El exportador NumPy original sirve para **acciones deterministas recortadas**. Su muestreo gaussiano crudo y sus log-probabilidades no representan esta nueva compresión de medias; por eso este modelo no se reanuda con el entrenador asíncrono genérico. Se carga mediante la clase PPO guardada y el runner dedicado.

## Evidencia y reproducción

- [Prueba completa](test_report.json), [validación](validation_report.json), [selección congelada](selection.json), [inicialización](initialization_report.json) y [entrenamiento](training_report.json).
- [Manifiesto de corrida](run_manifest.json), [auditoría independiente final](final_audit.json), [paridad física de la inicialización](env_preservation.json), [%(full_tests)d pruebas aprobadas](full_tests.log), [resultados](results.json) y [SHA de todos los archivos](artifacts.json).
- [Modelo](../../../../models/rl/striker_preserving_v4/README.md) y [ZIP completo](complete_run.zip): 96 checkpoints con pesos, Adam y RNG, base v2, rival congelado, caches pareados, progreso, diagnósticos, logs y los %(input_count)d inputs originales de fuentes, modelos, mallas y runtime. `onnxruntime.dll` está incluido en el fingerprint original de esta corrida. Las pruebas adicionales del ZIP están etiquetadas como snapshot de soporte si no formaron parte de esos hashes.

Fingerprint: `%(fingerprint)s`.

SHA256 del ZIP: `%(package_sha)s`.

```powershell
# Restaurar inputs/ en sus rutas, run/ en runs/striker_retrain_v2/preserving_v4
# y support/ en runs/striker_retrain_v2. Verificar artifact_manifest.json.
python tools/retrain_striker_v2.py --output runs/striker_retrain_v2/preserving_v4 `
  --workers 6 --n-steps 128 --updates 96 --checkpoint-every 32 `
  --validation-episodes 64 --test-episodes 100 --learning-rate 0.00003 `
  --max-seconds 7200 --retention-max-drop 0.10 --stage test --resume
```

Este comando valida identidad y reutiliza la prueba cacheada. Una repetición física independiente requiere otra carpeta, inputs y versiones congeladas, y el protocolo completo.
''' % {'conclusion': conclusion, 'update': selected['update'], 'table': '\n'.join(table),
       'gains': '\n'.join(gains), 'gate_table': '\n'.join(gate_table), 'val_table': '\n'.join(val_table),
       'training_episodes': len(state['episode_records']), 'training_goals': training_counts['goal'],
       'training_saves': training_counts['save'], 'training_misses': training_counts['miss'],
       'training_timeouts': training_counts['timeout'],
       'training_falls': training_counts['striker_fall']+training_counts['keeper_fall'],
       'selected_transitions': selected['update']*768,
       'failure_text': failure_text, 'full_tests': full_test_count, 'input_count': len(config['source_hashes']),
       'fingerprint': manifest['fingerprint'], 'package_sha': package_sha}


def export(expected_fingerprint):
    manifest, state, selected, validation, test, inputs, rec, failures, full_test_count = validate_completed_run(expected_fingerprint)
    manifest_path = ROOT/'models/rl/manifest.json'
    existing = read(manifest_path)
    protected_entries = deepcopy({name: entry for name, entry in existing.items() if name != 'striker_preserving_v4'})
    protected_v2_hashes = policy_hashes(ROOT/'models/rl/striker_v2')
    selected_directory = RUN/selected['policy']
    entries = archive_entries(inputs)
    for name in POLICY_FILES:
        immutable_copy(selected_directory/name, MODEL/name)
    if policy_hashes(MODEL) != selected['policy_sha256']:
        raise ValueError('exported policy bytes differ')
    for name in ('run_manifest.json', 'initialization_report.json', 'training_report.json',
                 'selection.json', 'test_report.json', 'final_audit.json', 'progress.json'):
        immutable_copy(RUN/name, REPORT/name)
    for path in sorted(RUN.glob('*audit*.json')):
        immutable_copy(path, REPORT/path.name)
    if (RUN/'failures.jsonl').exists():
        immutable_copy(RUN/'failures.jsonl', REPORT/'failures.jsonl')
    immutable_copy(RUN/'evaluations/validation_selection/report.json', REPORT/'validation_report.json')
    immutable_copy(SUPPORT_ROOT/'full_tests.log', REPORT/'full_tests.log')
    immutable_copy(SUPPORT_ROOT/'env_preservation.json', REPORT/'env_preservation.json')
    for path in sorted(SUPPORT_ROOT.glob('*audit*.json')):
        immutable_copy(path, REPORT/path.name)
    package_manifest, package_sha = make_zip(entries, manifest, selected)
    results = {'version': 'striker_preserving_results_export_v1', 'run_fingerprint': manifest['fingerprint'],
               'status': 'recommended_in_this_simulation' if rec['promoted'] else 'experimental',
               **rec, 'selected_update': selected['update'], 'test_used_for_selection': False,
               'hardware_validated': False, 'initialization': manifest['configuration']['initialization'],
               'training_transitions': state['training_transitions'],
               'selected_checkpoint_training_transitions': selected['update']*768,
               'training_transition_scope': 'completed optimized PPO transitions; discarded physical work counted only when known',
               'training_failure_log_entries': len(failures),
               'discarded_rollout_reservations': state.get('discarded_rollout_reservations', []),
               'failure_log_entries_are_unique_failures': False,
               'validation_summary': selected['validation_summary'], 'retention_summary': selected['retention_summary'],
               'validation_prefers_trained_over_v2': selected['validation_prefers_trained_over_v2'],
               'initialization_diagnostic': selected['initialization_diagnostic'],
               'summaries': test['summaries'], 'paired_comparisons': test['comparisons'],
               'selected_policy_sha256': selected['policy_sha256'],
               'selection_sha256': sha(RUN/'selection.json'), 'test_report_sha256': sha(RUN/'test_report.json'),
               'resume_state_sha256': sha(selected_directory/'resume_state.json'),
               'complete_run_zip_sha256': package_sha, 'original_frozen_input_count': len(inputs),
               'original_frozen_input_bytes': sum(item['bytes'] for item in inputs),
               'zip_entry_count': len(package_manifest['files'])+1, 'full_test_count': full_test_count,
               'limitations': manifest['limitations']}
    atomic_write(REPORT/'results.json', json_bytes(results))
    atomic_write(REPORT/'README.md', make_readme(manifest, state, selected, validation, test, package_sha,
                                               rec, failures, full_test_count).encode('utf-8'))
    model_readme = '''# striker_preserving_v4

Checkpoint PPO de la actualización %d, elegido con validación contra nuestro portero v2 balanced y la FSM base. `model.zip`, `obs_norm.npz` y `config.json` se exportan byte a byte. La recomendación de esta prueba es `%s`; consultar los criterios y resultados completos en el [reporte](../../../docs/validation/rl/striker_preserving_v4/README.md).

Mantiene `rl_obs_v1` de 19 campos, cuatro acciones tácticas e historia 1. La inicialización `striker_policy_init_v3` conserva el actor de v2 y la normalización, comprime sólo las colas de sus medias gaussianas durante entrenamiento, reinicia Adam y pone en cero el crítico final. Recompensa nueva `striker_visual_reward_v3`, gamma 1 y retorno terminal ±1.

El exportador NumPy original es compatible sólo para acciones deterministas recortadas. El muestreo asíncrono gaussiano genérico no sirve para reentrenar esta clase; usar el runner dedicado `tools/retrain_striker_v2.py`. Sin validación en hardware ni convergencia demostrada.

Fingerprint: `%s`.
''' % (selected['update'], rec['recommended_reference'], manifest['fingerprint'])
    atomic_write(MODEL/'README.md', model_readme.encode('utf-8'))
    entry = {'rol': 'striker', 'corrida': 'striker_preserving_v4', 'historia': 1,
             'estado': 'recomendado en esta prueba simulada' if rec['promoted'] else 'experimental; conservar striker_v2',
             'promoted': rec['promoted'], 'recommended_reference': rec['recommended_reference'],
             'entrenamiento': {'updates': 96, 'optimized_transitions': 73728,
                              'selected_checkpoint_optimized_transitions': selected['update']*768,
                              'opponents_by_worker': manifest['configuration']['training_opponents_by_worker'],
                              'seed_base': 101001, 'reward': 'striker_visual_reward_v3',
                              'initialization': 'striker_policy_init_v3', 'failure_log_entries': len(failures)},
             'validacion': {'episodes_per_opponent': 64, 'opponents': ['balanced', 'scripted'],
                            'selected_update': selected['update'], 'selected_summary': selected['validation_summary'],
                            'retention_summary': selected['retention_summary'],
                            'retention_gate_satisfied': selected['retention_gate_satisfied'],
                            'diagnostic_only': selected['diagnostic_only'], 'test_used_for_selection': False},
             'evaluacion': {'episodes_per_opponent': 100, 'summaries': test['summaries'],
                            'paired_comparisons': test['comparisons'], 'recommendation_criteria': rec['conditions'],
                            'retention_gate_is_formal_noninferiority_test': False, 'hardware_validated': False},
             'sha256': selected['policy_sha256'], 'run_fingerprint': manifest['fingerprint'],
             'report': 'docs/validation/rl/striker_preserving_v4/test_report.json',
             'reproducibility_bundle_sha256': package_sha}
    if 'striker_preserving_v4' in existing and existing['striker_preserving_v4'] != entry:
        raise ValueError('existing preserving model manifest entry differs')
    existing['striker_preserving_v4'] = entry
    if {name: value for name, value in existing.items() if name != 'striker_preserving_v4'} != protected_entries:
        raise ValueError('export changed a published model manifest entry')
    atomic_write(manifest_path, json_bytes(existing))
    checked_inputs(manifest)
    if (policy_hashes(ROOT/'models/rl/striker_v2') != protected_v2_hashes or
            sha(RUN/'test_report.json') != results['test_report_sha256'] or
            sha(RUN/'selection.json') != results['selection_sha256']):
        raise ValueError('protected base or final test/selection changed during export')
    files = {}
    for directory in (MODEL, REPORT):
        for path in sorted(directory.rglob('*')):
            if path.is_file() and path.name != 'artifacts.json':
                files[path.relative_to(ROOT).as_posix()] = {'sha256': sha(path), 'bytes': path.stat().st_size}
    atomic_write(REPORT/'artifacts.json', json_bytes({'version': 'striker_preserving_artifacts_v1',
                                                   'run_fingerprint': manifest['fingerprint'], 'files': files}))
    print(json.dumps({'model': str(MODEL), 'report': str(REPORT), 'selected_update': selected['update'],
                      'promoted': rec['promoted'], 'recommended_reference': rec['recommended_reference'],
                      'zip_sha256': package_sha, 'zip_bytes': (REPORT/'complete_run.zip').stat().st_size,
                      'run_fingerprint': manifest['fingerprint']}, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--export', action='store_true', help='execute only after explicit root authorization')
    parser.add_argument('--fingerprint', required=True, help='exact fingerprint authorized by root after final audit')
    args = parser.parse_args()
    if not args.export or not re.fullmatch(r'[0-9a-f]{64}', args.fingerprint):
        parser.error('--export and the exact authorized 64-character --fingerprint are required')
    export(args.fingerprint)
