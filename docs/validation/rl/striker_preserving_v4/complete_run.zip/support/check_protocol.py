"""Read-only independent check of the actual frozen preserving experiment."""
from datetime import datetime, timezone
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
import numpy as np
import torch
from stable_baselines3 import PPO

from penalty.rl import striker_retraining_v2 as training
from penalty.rl.striker_preserving_policy import actor_parameters_sha256


def main():
    output = training.ROOT/'runs/striker_retrain_v2/preserving_v4'
    manifest = training._read(output/'run_manifest.json')
    config = manifest['configuration']
    training.check_sources(output, manifest)
    assert training._digest(config) == manifest['fingerprint']
    assert config['split_bases'] == {'train': 101001, 'validation': 102001, 'test': 103001}
    assert config['training_opponents_by_worker'] == ['balanced']*5+['scripted']
    assert (config['updates'], config['workers'], config['ppo']['n_steps']) == (96, 6, 128)
    assert config['ppo']['gamma'] == 1. and config['reward'] == 'striker_visual_reward_v3'
    assert config['test_may_select_or_fit'] is False and config['async_training_compatible'] is False
    assert config['validation_opponents'] == ['balanced', 'scripted']
    assert (config['validation_episodes'], config['test_episodes']) == (64, 100)
    proof = training._read(output/'initialization_report.json')
    assert proof['fingerprint'] == manifest['fingerprint']
    assert training.policy_hashes(output/'initialized') == proof['policy_sha256']
    base = PPO.load(output/'frozen/striker_v2/model.zip', device='cpu')
    initialized = PPO.load(output/'initialized/model.zip', device='cpu')
    before, after = actor_parameters_sha256(base.policy), actor_parameters_sha256(initialized.policy)
    assert before == after == proof['proof']['base_actor_sha256']
    changed = [name for name, tensor in initialized.policy.state_dict().items()
               if not torch.equal(tensor, base.policy.state_dict()[name])]
    assert set(changed) == {'log_std', 'value_net.weight', 'value_net.bias'}
    assert initialized.policy.value_net.weight.count_nonzero().item() == 0
    assert initialized.policy.value_net.bias.count_nonzero().item() == 0
    assert len(initialized.policy.optimizer.state) == 0
    np.testing.assert_array_equal(initialized.policy.log_std.detach().exp().numpy(), [.25]*4)
    assert initialized.seed == config['exploration_seed'] == 101001
    assert initialized.num_timesteps == base.num_timesteps == 6052886
    assert training._sha(output/'initialized/obs_norm.npz') == training._sha(output/'frozen/striker_v2/obs_norm.npz')
    observations = np.random.default_rng(101001).uniform(-10., 10., (1024, 19)).astype(np.float32)
    a, _ = base.predict(observations, deterministic=True)
    b, _ = initialized.predict(observations, deterministic=True)
    np.testing.assert_array_equal(a, b)
    result = {'version': 'striker_preserving_protocol_audit_v1',
              'created_utc': datetime.now(timezone.utc).isoformat(),
              'run_fingerprint': manifest['fingerprint'], 'status': 'passed',
              'source_inputs_verified': len(config['source_hashes']),
              'baseline_original_files_verified': manifest['source']['baseline_integrity']['files'],
              'frozen_base_policy_sha256': config['base_policy_sha256'],
              'initialized_policy_sha256': proof['policy_sha256'],
              'actor_parameters_sha256': after, 'actor_parameters_byte_identical': True,
              'changed_parameter_names': changed, 'value_head_zero': True,
              'optimizer_initial_state_entries': 0, 'action_std': [.25]*4,
              'ppo_seed_metadata_and_exploration_seed': initialized.seed,
              'initial_num_timesteps': initialized.num_timesteps,
              'normalization_byte_identical': True,
              'deterministic_action_identity_checks': {'normalized_observations': 1024,
                                                      'bitwise_equal': True, 'maximum_absolute_difference': 0.},
              'objective': 'gamma=1, zero nonterminal reward, terminal +1 goal / -1 other valid result; expected return 2P(goal)-1',
              'training_worker_opponents': config['training_opponents_by_worker'],
              'training_budget_optimized_transitions': 96*6*128,
              'validation_seeds_per_policy_per_opponent': 64,
              'blind_test_seeds_per_policy_per_opponent': 100,
              'selection_uses_test': False, 'retention_is_formal_noninferiority_test': False,
              'promotion_rule': config['promotion_rule'],
              'physical_episodes_run_by_this_audit': 0,
              'scope': 'frozen protocol and actual initialized checkpoint, not a performance result'}
    training._write(output.parent/'protocol_audit.json', result)
    print({'status': 'passed', 'source_inputs': result['source_inputs_verified'],
           'actor_byte_identity': True, 'deterministic_actions_checked': 1024,
           'ppo_seed': initialized.seed, 'run_fingerprint': manifest['fingerprint']})


if __name__ == '__main__':
    main()
