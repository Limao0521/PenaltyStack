"""Physical initialization parity, outside all training/evaluation seeds."""
from concurrent.futures import ProcessPoolExecutor
import hashlib
import json
from pathlib import Path
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
OUTPUT = ROOT/'runs/striker_retrain_v2'


def episode(job):
    from penalty.rl.actors import NumpyPolicy, normalize
    from penalty.rl.striker_visual_env import StrikerVisualKeeperEnv
    from penalty.rl.striker_visual_env_v2 import StrikerVisualKeeperEnvV2
    records, children_closed = {}, {}
    for label, cls in (('v2', StrikerVisualKeeperEnv), ('initialized', StrikerVisualKeeperEnvV2)):
        env = cls(keeper_mode='balanced')
        spec = job[label]
        policy = NumpyPolicy(spec['params'])
        stats = (spec['mean'], spec['var'], spec['clip'], spec['epsilon'])
        processes = []
        trajectory = hashlib.sha256()
        try:
            obs, _ = env.reset(seed=job['seed'])
            for _ in range(500):
                processes.extend(env._processes())
                action = np.clip(policy.mean(normalize(obs, stats)), -1., 1.).astype(np.float32)
                trajectory.update(np.asarray(obs, dtype=np.float32).tobytes())
                trajectory.update(action.tobytes())
                obs, _, terminated, truncated, info = env.step(action)
                if terminated or truncated:
                    records[label] = info['episode_record']
                    records[label]['parity_observation_action_sha256'] = trajectory.hexdigest()
                    assert records[label]['result'] != 'sim_error', records[label]
                    break
            else:
                raise AssertionError('unbounded parity episode')
        finally:
            env.close()
            children_closed[label] = all(process.poll() is not None for process in processes)
    fields = ('result', 'steps', 'visible_frames', 'velocity_frames', 'first_trigger',
              'requested_defense', 'no_commit', 'fallen', 'target_y',
              'kick_side', 'kick_power', 'kick_time', 'parity_observation_action_sha256')
    for field in fields:
        assert field in records['v2'] and field in records['initialized'], field
        assert records['v2'][field] == records['initialized'][field], (field, records)
    for field in ('engine_seed', 'ball_xy', 'start_offsets'):
        assert records['v2']['reset_info'][field] == records['initialized']['reset_info'][field]
    assert all(children_closed.values())
    return {'seed': job['seed'], 'physical_fields_exact': True,
            'children_collected': children_closed, 'records': records}


def main():
    import gymnasium as gym
    from gymnasium import spaces
    from stable_baselines3.common.vec_env import DummyVecEnv, VecNormalize
    from penalty.rl.contracts import OBS_LOW, OBS_HIGH
    from penalty.rl.duel import export_trained
    from penalty.rl.striker_preserving_policy import initialize_preserving_model
    from penalty.rl.training import save_policy

    class ContractEnv(gym.Env):
        observation_space = spaces.Box(OBS_LOW, OBS_HIGH, dtype=np.float32)
        action_space = spaces.Box(-1., 1., (4,), dtype=np.float32)

        def reset(self, *, seed=None, options=None):
            super().reset(seed=seed)
            return np.zeros(19, dtype=np.float32), {}

        def step(self, action):
            return np.zeros(19, dtype=np.float32), 0., True, False, {}

    OUTPUT.mkdir(parents=True, exist_ok=True)
    target = OUTPUT/'preserved_initial_1'
    assert not target.exists(), 'parity output is immutable'
    base = ROOT/'models/rl/striker_v2'
    vector = DummyVecEnv([ContractEnv])
    with np.load(base/'obs_norm.npz', allow_pickle=False) as stats:
        norm = VecNormalize(vector, training=False, norm_obs=True, norm_reward=False,
                            clip_obs=float(stats['clip_obs']), epsilon=float(stats['epsilon']))
        norm.obs_rms.mean = stats['mean'].copy()
        norm.obs_rms.var = stats['var'].copy()
        norm.obs_rms.count = float(stats['count'])
    try:
        model, proof = initialize_preserving_model(base, norm, seed=101001, gamma=1., n_steps=128,
                                                  learning_rate=3e-5, n_epochs=4, batch_size=128,
                                                  clip_range=.05, target_kl=.01)
        save_policy(model, norm, target, 'striker', {'preflight_initialization_only': True,
                                                  'reward': 'striker_visual_reward_v3'})
    finally:
        norm.close()
    assert (base/'obs_norm.npz').read_bytes() == (target/'obs_norm.npz').read_bytes()
    original, preserved = export_trained(base), export_trained(target)
    jobs = [{'seed': 104001000000+i, 'v2': original, 'initialized': preserved} for i in range(2)]
    with ProcessPoolExecutor(max_workers=2) as pool:
        rows = list(pool.map(episode, jobs))
    result = {'version': 'preserving_initialization_physical_parity_v1',
              'outside_train_validation_test': True, 'initialization_proof': proof,
              'baseline_sha256': {name: hashlib.sha256((base/name).read_bytes()).hexdigest()
                                  for name in ('model.zip', 'obs_norm.npz', 'config.json')},
              'cases': rows, 'duels': 4, 'all_physical_fields_exact': True}
    (OUTPUT/'env_preservation.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'duels': 4, 'physical_parity_exact': True,
                      'actor_byte_identical': proof['actor_parameters_byte_identical']}, indent=2), flush=True)


if __name__ == '__main__':
    main()
