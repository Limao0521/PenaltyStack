"""Read immutable checkpoints and evidence; never create a physical environment."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import random
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
RUN = ROOT/'runs/striker_retrain_v2/preserving_v4'
FINGERPRINT = '3343ae9fee9a7ad2080bb26e9039fbc22958de62ebcadbaf60d322e9510256d7'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def envelope(path):
    value = read(path)
    assert value['version'] == 'striker_visual_checkpoint_v2'
    assert value['fingerprint'] == FINGERPRINT
    assert value['payload_sha256'] == hashlib.sha256(canonical(value['payload'])).hexdigest()
    return value['payload']


def files(directory):
    return {name: sha(directory/name) for name in ('model.zip', 'obs_norm.npz', 'config.json')}


def finite_nested(value):
    import torch
    if isinstance(value, torch.Tensor):
        return bool(torch.isfinite(value).all())
    if isinstance(value, dict):
        return all(finite_nested(item) for item in value.values())
    if isinstance(value, (tuple, list)):
        return all(finite_nested(item) for item in value)
    if isinstance(value, (float, np.floating)):
        return bool(np.isfinite(value))
    return True


def verify_rng(value):
    from penalty.rl.striker_retraining_v2 import _rng_restore, _rng_snapshot
    import torch
    old = _rng_snapshot()
    try:
        _rng_restore(value)
        first = (random.random(), float(np.random.random()), float(torch.rand(1)))
        _rng_restore(value)
        second = (random.random(), float(np.random.random()), float(torch.rand(1)))
        assert first == second
    finally:
        _rng_restore(old)


def audit_provisional():
    import torch
    from stable_baselines3 import PPO
    from penalty.rl.striker_preserving_policy import (
        PreservingActorCriticPolicy, actor_parameters_sha256,
    )
    torch.set_num_threads(1)
    manifest = read(RUN/'run_manifest.json')
    assert manifest['fingerprint'] == FINGERPRINT
    config = manifest['configuration']
    assert hashlib.sha256(canonical(config)).hexdigest() == FINGERPRINT
    for path, expected in config['source_hashes'].items():
        assert sha(ROOT/path) == expected, path
    from penalty.rl.striker_retraining_v2 import sources
    current = sources()
    assert current['hashes'] == config['source_hashes']
    assert current['versions'] == config['runtime_versions']
    originals = read(ROOT/'baseline/motion_manifest.json')['files']
    for path, expected in originals.items():
        assert sha(ROOT/'baseline/bhuman'/path) == expected, path
    assert len(originals) == 559
    assert files(RUN/'frozen/striker_v2') == config['base_policy_sha256']
    assert files(ROOT/'models/rl/striker_v2') == config['base_policy_sha256']
    assert sha(RUN/'frozen/keeper_motion_v1.json') == config['motion_model_sha256']
    assert config['workers'] == 6 and config['updates'] == 96
    assert config['ppo'] == dict(n_steps=128, batch_size=128, n_epochs=4,
        learning_rate=3e-5, ent_coef=0., target_kl=.01, clip_range=.05,
        gamma=1., gae_lambda=.95)
    assert config['training_opponents_by_worker'] == ['balanced']*5+['scripted']
    assert config['validation_opponents'] == ['balanced', 'scripted']
    assert config['test_opponents'] == ['balanced', 'motion', 'scripted']
    assert config['split_bases'] == dict(train=101001, validation=102001, test=103001)
    assert config['exploration_seed'] == 101001
    assert (config['validation_episodes'], config['test_episodes']) == (64, 100)
    assert config['retention_max_drop'] == .10
    assert config['test_may_select_or_fit'] is False
    assert config['async_training_compatible'] is False
    assert config['head_rows_rescaled'] is False
    init_report = read(RUN/'initialization_report.json')
    assert init_report['fingerprint'] == FINGERPRINT
    assert files(RUN/'initialized') == init_report['policy_sha256']
    assert (RUN/'initialized/obs_norm.npz').read_bytes() == (RUN/'frozen/striker_v2/obs_norm.npz').read_bytes()
    base = PPO.load(RUN/'frozen/striker_v2/model.zip', device='cpu')
    init = PPO.load(RUN/'initialized/model.zip', device='cpu')
    assert isinstance(init.policy, PreservingActorCriticPolicy)
    assert init.seed == 101001 and init.gamma == 1.
    assert actor_parameters_sha256(init.policy) == actor_parameters_sha256(base.policy)
    assert actor_parameters_sha256(init.policy) == init_report['proof']['base_actor_sha256']
    changed = []
    for name, before in base.policy.state_dict().items():
        if not torch.equal(init.policy.state_dict()[name], before):
            changed.append(name)
    assert set(changed) == {'log_std', 'value_net.weight', 'value_net.bias'}
    assert len(init.policy.optimizer.state) == 0
    assert not bool(init.policy.value_net.weight.any()) and not bool(init.policy.value_net.bias.any())
    np.testing.assert_array_equal(init.policy.log_std.detach().exp().numpy(), np.full(4, .25, np.float32))
    obs = np.random.default_rng(104001).uniform(-10, 10, (2048, 19)).astype(np.float32)
    a, _ = base.predict(obs, deterministic=True)
    b, _ = init.predict(obs, deterministic=True)
    np.testing.assert_array_equal(a, b)
    checkpoints = []
    previous_records = []
    for directory in sorted((RUN/'checkpoints').glob('update_*')):
        if not directory.is_dir() or '.tmp-' in directory.name:
            continue
        update = int(directory.name.rsplit('_', 1)[1])
        state = envelope(directory/'resume_state.json')
        assert state['completed_updates'] == update
        assert state['checkpoint'] == directory.relative_to(RUN).as_posix()
        assert state['checkpoint_sha256'] == files(directory)
        assert state['training_transitions'] == update*768
        assert state['episode_records'][:len(previous_records)] == previous_records
        previous_records = state['episode_records']
        seeds = [row['seed'] for row in previous_records]
        assert len(seeds) == len(set(seeds))
        assert all(101001000000 <= seed < 101002000000 for seed in seeds)
        assert not any(row['result'] == 'sim_error' for row in previous_records)
        for row in previous_records:
            assert row['environment']['reward'] == 'striker_visual_reward_v3'
            assert row['return'] == (1. if row['result'] == 'goal' else -1.)
            keeper = row['environment']['keeper_mode']
            assert keeper == config['training_opponents_by_worker'][row['worker_index']]
        assert (directory/'obs_norm.npz').read_bytes() == (RUN/'frozen/striker_v2/obs_norm.npz').read_bytes()
        model = PPO.load(directory/'model.zip', device='cpu')
        assert isinstance(model.policy, PreservingActorCriticPolicy)
        assert model.seed == 101001 and model.gamma == 1.
        assert model.num_timesteps == base.num_timesteps+update*768
        assert finite_nested(model.policy.state_dict()) and finite_nested(model.policy.optimizer.state_dict())
        sigma = model.policy.log_std.detach().exp().numpy()
        assert bool(((sigma >= .12-1e-7) & (sigma <= .40+1e-7)).all())
        assert len(model.policy.optimizer.state) > 0
        verify_rng(state['rng'])
        checkpoints.append(dict(update=update, policy_sha256=files(directory),
            resume_state_sha256=sha(directory/'resume_state.json'),
            actor_parameters_changed=actor_parameters_sha256(model.policy) != actor_parameters_sha256(init.policy),
            optimizer_state_finite=True, policy_parameters_finite=True,
            saved_action_std=sigma.tolist(), total_model_timesteps=int(model.num_timesteps),
            completed_record_count=len(previous_records), rng_schema_restore_verified=True))
    progress = envelope(RUN/'progress.json')
    verify_rng(progress['rng'])
    parity = read(ROOT/'runs/striker_retrain_v2/env_preservation.json')
    assert parity['outside_train_validation_test'] is True and len(parity['cases']) == 2
    for case in parity['cases']:
        assert case['physical_fields_exact'] is True
        assert all(case['children_collected'].values())
        assert 104001000000 <= case['seed'] < 104002000000
    testlog = (ROOT/'runs/striker_retrain_v2/full_tests.log').read_text()
    assert 'Ran 367 tests in 92.434s' in testlog and testlog.rstrip().endswith('OK')
    first_preflight = (ROOT/'runs/striker_retrain_v2/env_preservation.log').read_text()
    assert "got multiple values for keyword argument 'history'" in first_preflight
    smoke = read(ROOT/'runs/striker_retrain_v2/smoke_v1/training_report.json')['state']
    assert smoke['completed_updates'] == 1 and smoke['training_transitions'] == 64
    assert len(smoke['episode_records']) == 0
    value = dict(version='striker_preserving_provisional_audit_v1',
        created_utc=datetime.now(timezone.utc).isoformat(),
        phase='ongoing training; validation and blind test not audited',
        run_fingerprint=FINGERPRINT, run_manifest_sha256=sha(RUN/'run_manifest.json'),
        source_files_verified_unchanged=len(config['source_hashes']),
        baseline_bhuman_files_verified_unchanged=len(originals),
        initialized_policy_sha256=files(RUN/'initialized'),
        initialized_actor_parameters_byte_identical=True,
        actor_parameters_sha256=actor_parameters_sha256(init.policy),
        initialized_only_parameters_changed=changed, initialized_optimizer_state_entries=0,
        initial_sigma=[.25]*4, initial_value_head_zeroed=True,
        normalization_npz_byte_identical=True, deterministic_torch_parity_observations=2048,
        deterministic_physical_parity_episodes=4,
        physical_parity_report_sha256=sha(ROOT/'runs/striker_retrain_v2/env_preservation.json'),
        seed_metadata_and_effective_initialization=101001,
        checkpoints_verified=checkpoints, snapshot_progress_updates=progress['completed_updates'],
        snapshot_completed_episode_counts=dict(Counter(row['result'] for row in previous_records)),
        script_worker_fraction='1 of 6 workers; episode counts depend on episode lengths',
        full_test_count=367, full_test_log_sha256=sha(ROOT/'runs/striker_retrain_v2/full_tests.log'),
        smoke_optimized_transitions=64, smoke_complete_episodes=0,
        preflight_helper_failure=dict(scope='artifact save before any parity physics; duplicate history keyword',
            training_failure=False, discarded_output='preserved_initial', successful_retry_output='preserved_initial_1'),
        final_audit_complete=False, physics_executed_by_auditor=False,
        validation_test_seeds_consumed_by_auditor=False, performance_improvement_claimed=False,
        remaining_checks=['all completed PPO updates', 'validation selection/retention gate',
            'all independent blind pairs and exact metrics/bootstrap', 'failure/cleanup audit at completion'])
    (RUN/'provisional_audit.json').write_text(json.dumps(value, indent=2, allow_nan=False)+'\n', encoding='utf-8')
    print(json.dumps({k: value[k] for k in ('phase', 'run_fingerprint',
        'source_files_verified_unchanged', 'baseline_bhuman_files_verified_unchanged',
        'snapshot_progress_updates', 'snapshot_completed_episode_counts')}, indent=2))
    return value


def paired_comparison(candidate, baseline):
    a = {row['seed']: row for row in candidate}
    b = {row['seed']: row for row in baseline}
    assert len(a) == len(candidate) and len(b) == len(baseline) and set(a) == set(b)
    difference = np.array([int(a[seed]['result'] == 'goal')-int(b[seed]['result'] == 'goal')
                           for seed in sorted(a)])
    resampled = np.random.default_rng(101001).choice(difference, (10000, len(difference)), replace=True).mean(1)
    return dict(episodes=len(difference), goal_gain=float(difference.mean()),
        goal_gain_ci95=np.quantile(resampled, [.025, .975]).tolist(),
        candidate_only_goals=int((difference == 1).sum()),
        baseline_only_goals=int((difference == -1).sum()),
        ci_method='paired bootstrap of goal indicator, all scheduled episodes')


def summary(rows):
    count = Counter(row['result'] for row in rows)
    n = len(rows)
    z, p = 1.96, count['goal']/n
    denominator = 1+z*z/n
    centre = (p+z*z/(2*n))/denominator
    half = z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/denominator
    return dict(episodes=n, counts=dict(sorted(count.items())), goal_rate=p,
        save_rate=count['save']/n, goal_ci95=[max(0., centre-half), min(1., centre+half)],
        sim_errors=count['sim_error'], striker_fall_rate=sum(bool(row.get('striker_fallen')) for row in rows)/n,
        denominator='all scheduled episodes, including misses/falls/timeout/simulation errors')


def verify_evaluation(path, split, policies, modes, config):
    report = read(path)
    count = config[split+'_episodes']
    identity = dict(run=FINGERPRINT, evaluation='striker_visual_crossplay_v2',
        split=split, policies={name: files(directory) for name, directory in policies.items()},
        modes=list(modes), episodes=count)
    fingerprint = hashlib.sha256(canonical(identity)).hexdigest()
    assert report['version'] == 'striker_visual_crossplay_v2'
    assert report['identity'] == identity and report['fingerprint'] == fingerprint
    assert report['split'] == split
    assert len(report['rows']) == len(modes)*count
    grouped = {mode: {name: [] for name in policies} for mode in modes}
    seen, native = set(), 0
    for row in sorted(report['rows'], key=lambda item: (item['keeper_mode'], item['seed'])):
        mode, seed = row['keeper_mode'], row['seed']
        assert mode in modes
        assert config['split_bases'][split]*1000000 <= seed < config['split_bases'][split]*1000000+count
        assert (mode, seed) not in seen
        seen.add((mode, seed))
        cache = path.parent/(mode+'-'+str(seed)+'.json')
        cached = read(cache)
        assert cached['version'] == 'striker_visual_checkpoint_v2'
        assert cached['fingerprint'] == fingerprint
        assert cached['payload_sha256'] == hashlib.sha256(canonical(cached['payload'])).hexdigest()
        assert cached['payload'] == row
        assert row['children_collected'] is True
        assert row['owned_native_children'] > 0
        native += row['owned_native_children']
        assert set(row['records']) == set(policies)
        first_reset = None
        for name, record in row['records'].items():
            assert record['seed'] == seed and record['split'] == split
            assert record['result'] != 'sim_error'
            assert record['environment']['reward'] == 'striker_visual_reward_v3'
            assert record['return'] == (1. if record['result'] == 'goal' else -1.)
            physical_reset = {key: record['reset_info'][key] for key in ('engine_seed', 'ball_xy', 'start_offsets')}
            if first_reset is None:
                first_reset = physical_reset
            else:
                assert physical_reset == first_reset
            grouped[mode][name].append(record)
    assert report['records'] == grouped
    for mode, peers in grouped.items():
        for name, rows in peers.items():
            assert len(rows) == count
            assert report['summaries'][mode][name] == summary(rows)
    return report, dict(physical_cases=len(seen), policy_duels=len(seen)*len(policies),
        native_children_verified_closed=native, exact_physical_pairing=True,
        caches_and_policy_hashes_verified=True, summaries_wilson_recomputed=True,
        simulation_errors=0)


def audit_final():
    # Run the full source/model checkpoint audit again against completed artifacts.
    value = audit_provisional()
    assert value['snapshot_progress_updates'] == 96
    assert [row['update'] for row in value['checkpoints_verified']] == list(range(1, 97))
    config = read(RUN/'run_manifest.json')['configuration']
    training = read(RUN/'training_report.json')
    state = envelope(RUN/'progress.json')
    assert training['fingerprint'] == FINGERPRINT and training['state'] == state
    assert state['training_transitions'] == 73728 and state['completed_updates'] == 96
    assert state['stop'] == 'fixed_update_budget'
    assert 'inflight_rollout' not in state and 'failure_status' not in state
    val_path = RUN/'evaluations/validation_selection/report.json'
    val_policies = {'v2': RUN/'frozen/striker_v2', 'initialized': RUN/'initialized',
        **{'update_%04d' % update: RUN/'checkpoints'/('update_%04d' % update) for update in (32, 64, 96)}}
    validation, val_audit = verify_evaluation(val_path, 'validation', val_policies,
                                            ('balanced', 'scripted'), config)
    for mode in ('balanced', 'scripted'):
        # Frozen actor + new Gaussian deterministic clipping must preserve each initial duel.
        old = validation['records'][mode]['v2']
        new = validation['records'][mode]['initialized']
        for a, b in zip(old, new):
            for key in ('result', 'steps', 'kick_time', 'contact_time', 'commit_time',
                        'target_y', 'kick_side', 'kick_power', 'striker_fallen', 'keeper_fallen'):
                assert a.get(key) == b.get(key), (mode, a['seed'], key)
    selected = envelope(RUN/'selection.json')
    assert selected['test_used_for_selection'] is False
    assert selected['validation_report_sha256'] == sha(val_path)
    assert selected['retention_gate_is_formal_noninferiority_test'] is False
    candidates = selected['candidates']
    assert [row['update'] for row in candidates] == [0, 32, 64, 96]
    baseline, trained = candidates[0], candidates[1:]
    for row in candidates:
        name = 'v2' if row['update'] == 0 else 'update_%04d' % row['update']
        assert row['summary'] == validation['summaries']['balanced'][name]
        assert row['retention_summary'] == validation['summaries']['scripted'][name]
        assert row['policy_sha256'] == files(RUN/row['policy'])
        if row['update']:
            assert row['vs_v2'] == paired_comparison(validation['records']['balanced'][name], validation['records']['balanced']['v2'])
            assert row['retention_vs_v2'] == paired_comparison(validation['records']['scripted'][name], validation['records']['scripted']['v2'])
            assert row['vs_initialized'] == paired_comparison(validation['records']['balanced'][name], validation['records']['balanced']['initialized'])
    eligible = [row for row in trained if row['retention_summary']['goal_rate']+1e-12 >= baseline['retention_summary']['goal_rate']-.10]
    order = lambda row: (-row['summary']['goal_rate'], row['summary']['striker_fall_rate'], row['update'])
    chosen = min(eligible or trained, key=order)
    best_eligible = min(eligible, key=order) if eligible else None
    promotion = best_eligible if best_eligible and best_eligible['summary']['goal_rate'] > baseline['summary']['goal_rate'] else baseline
    assert selected['update'] == chosen['update'] and selected['policy'] == chosen['policy']
    assert selected['policy_sha256'] == chosen['policy_sha256']
    assert selected['validation_summary'] == chosen['summary']
    assert selected['retention_summary'] == chosen['retention_summary']
    assert selected['retention_gate_satisfied'] == bool(eligible)
    assert selected['diagnostic_only'] == (not bool(eligible))
    assert selected['promotion_candidate'] == promotion
    assert selected['validation_prefers_trained_over_v2'] == (promotion['update'] > 0)
    test_path = RUN/'evaluations/blind_test/report.json'
    test, test_audit = verify_evaluation(test_path, 'test',
        {'v2': RUN/'frozen/striker_v2', 'selected': RUN/selected['policy']},
        ('balanced', 'motion', 'scripted'), config)
    full_test = read(RUN/'test_report.json')
    for key, actual in test.items():
        assert full_test[key] == actual
    assert full_test['selection_sha256'] == sha(RUN/'selection.json')
    assert full_test['policy_sha256'] == selected['policy_sha256']
    assert full_test['selected_update'] == selected['update']
    assert full_test['model_frozen_before_test'] is True and full_test['test_used_for_selection'] is False
    assert full_test['run_fingerprint'] == FINGERPRINT
    comparisons = {mode: paired_comparison(peers['selected'], peers['v2']) for mode, peers in test['records'].items()}
    assert full_test['comparisons'] == comparisons
    promote = (promotion['update'] > 0 and comparisons['balanced']['goal_gain_ci95'][0] > 0.
               and comparisons['scripted']['goal_gain'] >= -.10)
    failures = [json.loads(row) for row in (RUN/'failures.jsonl').read_text().splitlines()] if (RUN/'failures.jsonl').exists() else []
    value.update(version='striker_preserving_final_audit_v1',
        phase='training, validation and blind evaluation complete', evaluation_complete=True,
        final_audit_complete=True, training_report_sha256=sha(RUN/'training_report.json'),
        selection_sha256=sha(RUN/'selection.json'), test_report_sha256=sha(RUN/'test_report.json'),
        selected_update=selected['update'], selected_policy_sha256=selected['policy_sha256'],
        validation=val_audit, test=test_audit, training_optimized_transitions=73728,
        initialization_validation_physical_parity_duels=256,
        all_bootstrap_comparisons_recomputed=True, training_failure_rows=len(failures),
        complete_training_physical_transition_count_claimed=False,
        conclusion=dict(promote_retrained_policy=promote,
            recommended_policy='striker_preserving_v4' if promote else 'striker_v2',
            formal_retention_noninferiority_established=False,
            convergence_established=False, promotion_rule_fixed_before_training=True),
        remaining_checks=[])
    (RUN/'final_audit.json').write_text(json.dumps(value, indent=2, allow_nan=False)+'\n', encoding='utf-8')
    print(json.dumps({key: value[key] for key in ('phase', 'selected_update', 'validation', 'test', 'conclusion')}, indent=2))


if __name__ == '__main__':
    if '--final' in sys.argv:
        audit_final()
    else:
        audit_provisional()
