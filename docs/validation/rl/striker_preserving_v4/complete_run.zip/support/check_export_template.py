"""Pure exporter checks with artificial data; no simulation or output export."""
from copy import deepcopy
import importlib.util
from pathlib import Path


path = Path(__file__).with_name('export_results.py')
spec = importlib.util.spec_from_file_location('preserving_export_test', path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
assert not module.MODEL.exists()
assert not module.REPORT.exists()
configuration = {'test_opponents': ['balanced', 'motion', 'scripted'],
                 'validation_opponents': ['balanced', 'scripted'],
                 'source_hashes': {str(i): '0'*64 for i in range(121)},
                 'retention_max_drop': .10}
manifest = {'configuration': configuration, 'fingerprint': 'a'*64}
rows = lambda n, g: [{'result': 'goal' if i < g else 'miss' if i == n-1 else 'save'} for i in range(n)]
test = {'records': {mode: {'v2': rows(100, 20), 'selected': rows(100, 30)}
                    for mode in configuration['test_opponents']},
        'comparisons': {mode: {'goal_gain': .10, 'goal_gain_ci95': [.01, .20],
                              'candidate_only_goals': 15, 'baseline_only_goals': 5}
                        for mode in configuration['test_opponents']}}
validation = {'records': {mode: {name: rows(64, 16 if name in ('v2', 'initialized') else 20)
                                for name in ('v2', 'initialized', 'update_0032', 'update_0064', 'update_0096')}
                          for mode in configuration['validation_opponents']}}
selected = {'update': 32, 'validation_prefers_trained_over_v2': True,
            'validation_summary': {'goal_rate': 20/64},
            'candidates': [{'update': 0, 'summary': {'goal_rate': 16/64}}],
            'retention_gate_satisfied': True, 'diagnostic_only': False}
state = {'episode_records': rows(100, 30)}
rec = module.recommendation(selected, test, configuration)
assert rec['promoted']
rendered = module.make_readme(manifest, state, selected, validation, test, 'b'*64, rec, [], 368)
assert '30 (30,00 %)' in rendered
assert '73.728' in rendered and 'striker_visual_reward_v3' in rendered
assert 'No se registró ninguna interrupción ni descarte' in rendered
assert 'reinicia Adam completo' in rendered
assert not module.MODEL.exists() and not module.REPORT.exists()

# A selector may prefer an equal-goal model with fewer falls. That is still
# insufficient for the STRICT primary promotion rule.
tied = deepcopy(selected)
tied['validation_summary']['goal_rate'] = 16/64
assert tied['validation_prefers_trained_over_v2']
assert not module.recommendation(tied, test, configuration)['promoted']
for gate in ('retention_gate_satisfied',):
    rejected = deepcopy(selected)
    rejected[gate] = False
    assert not module.recommendation(rejected, test, configuration)['promoted']
diagnostic = deepcopy(selected)
diagnostic['diagnostic_only'] = True
assert not module.recommendation(diagnostic, test, configuration)['promoted']
low = deepcopy(test)
low['comparisons']['balanced']['goal_gain_ci95'][0] = 0.
assert not module.recommendation(selected, low, configuration)['promoted']
regressed = deepcopy(test)
regressed['comparisons']['scripted']['goal_gain'] = -.11
assert not module.recommendation(selected, regressed, configuration)['promoted']
borderline = deepcopy(test)
borderline['comparisons']['scripted']['goal_gain'] = -.10
assert module.recommendation(selected, borderline, configuration)['promoted']
failed_rec = module.recommendation(selected, regressed, configuration)
rendered = module.make_readme(manifest, state, selected, validation, regressed, 'c'*64,
                              failed_rec, [{'phase': 'worker'}, {'phase': 'parent'}], 368)
assert 'conserva striker_v2' in rendered
assert 'diagnóstico en el registro durable: 2' in rendered
reserved = deepcopy(state)
reserved['discarded_rollout_reservations'] = [{'start_index': 0, 'end_index_exclusive': 774}]
rendered = module.make_readme(manifest, reserved, selected, validation, test, 'd'*64,
                              failed_rec, [], 368)
assert 'diagnóstico en el registro durable: 0' in rendered
assert 'reservas de rollouts descartados en el progreso: 1'.lower() in rendered.lower()
assert not module.MODEL.exists() and not module.REPORT.exists()
print('Exporter compiled; artificial README, strict promotion gates and no-output checks passed.')
