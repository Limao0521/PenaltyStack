"""Compact read-only state of the frozen experiment."""
import json
from pathlib import Path

root = Path(__file__).resolve().parent/'preserving_v4'
state = json.loads((root/'progress.json').read_text())['payload']
stage = 'test' if (root/'selection.json').exists() else ('validation' if (root/'training_report.json').exists() else 'training')
if (root/'test_report.json').exists():
    stage = 'complete'
print(json.dumps({'phase': stage, 'updates': state['completed_updates'],
                  'transitions': state['training_transitions'],
                  'complete_training_episodes': len(state['episode_records']),
                  'optimized_training_minutes': round(state['elapsed_s']/60, 1),
                  'failed': state.get('failed', False),
                  'failure_files': [p.name for p in root.glob('*failure*')],
                  'evaluation_cache_counts': {d.name: len(list(d.glob('*.json')))
                                              for d in (root/'evaluations').glob('*/cases')}},
                 ensure_ascii=False))
