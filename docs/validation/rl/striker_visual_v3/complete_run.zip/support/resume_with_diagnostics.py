"""Record a stopped rollout and resume the frozen trainer without changing it."""
import json
from pathlib import Path
import runpy
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))


def diagnostic_trace(frame, event, arg):
    if frame.f_code.co_name != '_on_step' or not frame.f_code.co_filename.endswith('striker_retraining.py'):
        return None
    if event == 'exception' and isinstance(arg[1], RuntimeError):
        record = frame.f_locals.get('record')
        if isinstance(record, dict) and record.get('result') == 'sim_error':
            path = Path(__file__).parent/'visual_v3'/('rollout_error-'+str(time.time_ns())+'.json')
            path.write_text(json.dumps({'version': 'failed_rollout_diagnostic_v1',
                                        'record': record, 'exception': str(arg[1]),
                                        'optimizer_update_completed': False},
                                       indent=2, allow_nan=False)+'\n', encoding='utf-8')
    return diagnostic_trace


if __name__ == '__main__':
    from penalty.rl.striker_retraining import _read_envelope, _write, _envelope
    output = Path(__file__).parent/'visual_v3'
    manifest = json.loads((output/'run_manifest.json').read_text())
    state = _read_envelope(output/'progress.json', manifest['fingerprint'])
    old = state['episode_start']
    # Failed rollouts were never optimized. Reserve their maximum possible
    # reset count rather than risk repeating an already simulated seed.
    reserve = manifest['configuration']['workers']*(manifest['configuration']['ppo']['n_steps']+1)
    state['episode_start'] += reserve
    recovery = {'version': 'failed_rollout_recovery_v1', 'completed_updates': state['completed_updates'],
                'old_episode_start': old, 'new_episode_start': state['episode_start'],
                'reserved_indices': reserve, 'maximum_resets_bound': 'workers * (n_steps + 1)',
                'last_complete_checkpoint_preserved': True, 'sources_changed': False,
                'partial_rollout_not_optimized': True, 'failure_not_excluded_from_experiment_history': True}
    _write(output/('recovery-'+str(time.time_ns())+'.json'), recovery)
    _write(output/'progress.json', _envelope(state, manifest['fingerprint']))
    sys.argv = ['tools/retrain_striker.py', '--output', str(output), '--calibration-report',
                str(Path(__file__).parent/'calibration_v1/calibration_report.json'), '--resume', '--stage', 'all']
    sys.settrace(diagnostic_trace)
    try:
        runpy.run_path(str(ROOT/'tools/retrain_striker.py'), run_name='__main__')
    finally:
        sys.settrace(None)
