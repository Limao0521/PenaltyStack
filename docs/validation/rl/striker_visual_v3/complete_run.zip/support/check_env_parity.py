"""Physical parity check outside the train/validation/test seed namespaces."""
from concurrent.futures import ProcessPoolExecutor
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))


def case(job):
    from penalty.keeper_library import VisionLibraryKeeper
    from penalty.rl.defense_benchmark import SensorDefenseDuelWorld
    from penalty.rl.duel import make_player
    from penalty.rl.selector_training import run_camera_episode
    from penalty.rl.striker_visual_env import StrikerVisualKeeperEnv
    from penalty.sim_orientation import SensorBHumanKeeperCamera
    seed, spec = job
    world = SensorDefenseDuelWorld(ball_jitter=.05, start_jitter=(.05, .1))
    camera = None
    try:
        world._ensure_session()
        camera = SensorBHumanKeeperCamera(world)
        old = run_camera_episode(world, camera, make_player(spec, 'striker'),
                                 VisionLibraryKeeper('balanced'), seed)
    finally:
        try:
            if camera is not None:
                camera.close()
        finally:
            world.close()
    env = StrikerVisualKeeperEnv()
    children = []
    try:
        player = make_player(spec, 'striker')
        player.reset()
        obs, _ = env.reset(seed=seed)
        children = env._processes()
        for _ in range(500):
            obs, _, terminated, truncated, info = env.step(player(obs))
            if terminated or truncated:
                new = info['episode_record']
                break
        else:
            raise RuntimeError('bounded episode did not finish')
    finally:
        env.close()
    fields = ('result', 'steps', 'visible_frames', 'velocity_frames',
              'first_trigger', 'requested_defense', 'no_commit',
              'striker_fallen', 'keeper_fallen')
    same = {key: old.get(key) == new.get(key) for key in fields}
    for key in ('engine_seed', 'ball_xy', 'start_offsets'):
        same['reset_'+key] = old['reset_info'][key] == new['reset_info'][key]
    if not all(same.values()) or not all(p.poll() is not None for p in children):
        raise RuntimeError('physical env parity failed: '+str(same))
    return dict(seed=seed, equal=same, old=old, new=new, children_collected=True)


if __name__ == '__main__':
    from penalty.rl.duel import export_trained
    spec = export_trained(ROOT/'models/rl/striker_v2')
    with ProcessPoolExecutor(max_workers=2) as pool:
        rows = list(pool.map(case, [(94001000000+i, spec) for i in range(2)]))
    report = dict(version='striker_visual_env_physical_parity_v1',
                  reserved_seeds_used=False, episodes=4, rows=rows)
    (Path(__file__).parent/'env_parity.json').write_text(
        json.dumps(report, indent=2, allow_nan=False)+'\n', encoding='utf-8')
    print('Physical parity: 2 paired seeds, all checks passed', flush=True)
