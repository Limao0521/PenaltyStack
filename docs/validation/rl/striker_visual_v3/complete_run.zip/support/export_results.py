"""Export the completed frozen striker pilot without training or simulation.

Run only after the root agent has authorized final export. This script reads
and verifies immutable evidence, copies the validation-selected checkpoint
byte-for-byte and builds a deterministic ZIP snapshot. It never imports the
simulator, PPO trainer or a tactical policy and never consumes physics seeds.
"""
from collections import Counter
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shutil
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo


ROOT = Path(__file__).resolve().parents[2]
RUN = ROOT/'runs/striker_retrain/visual_v3'
MODEL = ROOT/'models/rl/striker_visual_v3'
REPORT = ROOT/'docs/validation/rl/striker_visual_v3'
POLICY_FILES = ('model.zip', 'obs_norm.npz', 'config.json')
EXPECTED_FINGERPRINT = 'dea1c26dc1fe338f884b86edccea6ef84e988dd65a0e3b7529c2e131b35fb7ed'
RESULTS = ('goal', 'save', 'miss', 'striker_fall', 'keeper_fall', 'timeout', 'sim_error')
SUPPORT = (
    'calibration_audit.json', 'env_parity.json', 'warmstart_audit.json',
    'design_audit.json', 'full_tests.log', 'preflight_tests.log',
    'calibration.log', 'env_parity.log', 'visual_v3.log',
    'check_env_parity.py', 'export_results.py',
)
STANDALONE = (
    'run_manifest.json', 'initialization_report.json', 'training_report.json',
    'selection.json', 'test_report.json', 'final_audit.json',
    'failure_history.json', 'recovery_audit.json',
    'validation_audit.json', 'completed_training_audit.json',
)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode('utf-8')


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    def invalid(value):
        raise ValueError('nonfinite JSON: '+value)
    return json.loads(Path(path).read_text(encoding='utf-8'), parse_constant=invalid)


def json_bytes(value):
    return (json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False)+'\n').encode('utf-8')


def atomic_write(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name+'.tmp-'+str(os.getpid()))
    try:
        temporary.write_bytes(data)
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def immutable_copy(source, target):
    source, target = Path(source), Path(target)
    if target.exists():
        if target.read_bytes() != source.read_bytes():
            raise ValueError('refusing to replace different exported bytes: '+str(target))
        return
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
    if sha(source) != sha(target):
        raise ValueError('copy checksum mismatch')


def envelope(path, fingerprint):
    data = read(path)
    if (data.get('version') != 'striker_visual_checkpoint_v1' or
            data.get('fingerprint') != fingerprint or
            data.get('payload_sha256') != digest(data.get('payload'))):
        raise ValueError('checkpoint envelope differs: '+str(path))
    return data['payload']


def policy_hashes(directory):
    return {name: sha(Path(directory)/name) for name in POLICY_FILES}


def physical_reset(record):
    data = record['reset_info']
    return {name: data[name] for name in ('engine_seed', 'ball_xy', 'start_offsets')}


def summary(records):
    if not records or any(row['result'] not in RESULTS for row in records):
        raise ValueError('empty or invalid episode records')
    counts = Counter(row['result'] for row in records)
    return {'episodes': len(records), 'counts': {name: counts[name] for name in RESULTS},
            'goal_rate': counts['goal']/len(records),
            'save_rate': counts['save']/len(records),
            'denominator': 'todos los episodios programados, incluidos fallos/caídas/timeout/errores'}


def checked_inputs(manifest):
    expected = manifest['configuration']['source_hashes']
    if len(expected) != 116:
        raise ValueError('expected the original 116 frozen inputs')
    result = []
    for relative, checksum in sorted(expected.items()):
        path = (ROOT/relative).resolve()
        if not path.is_relative_to(ROOT.resolve()) or sha(path) != checksum:
            raise ValueError('frozen source/input bytes changed: '+relative)
        result.append({'path': path, 'archive': 'inputs/'+relative.replace('\\', '/'),
                       'sha256': checksum, 'bytes': path.stat().st_size,
                       'role': 'original_frozen_input'})
    # The imported original detector needs this DLL on Windows. Its bytes were
    # not part of the original 116-input cache key; label that distinction.
    dependency = ROOT/'native/bhuman_motion/build/vision/Release/onnxruntime.dll'
    if not dependency.is_file():
        raise ValueError('the recorded detector runtime DLL is unavailable')
    if dependency.relative_to(ROOT).as_posix() not in expected:
        result.append({'path': dependency, 'archive': 'inputs/'+dependency.relative_to(ROOT).as_posix(),
                       'sha256': sha(dependency), 'bytes': dependency.stat().st_size,
                       'role': 'runtime_dependency_not_in_original_116'})
    return result


def validate_completed_run():
    manifest = read(RUN/'run_manifest.json')
    fingerprint = manifest['fingerprint']
    if fingerprint != EXPECTED_FINGERPRINT or digest(manifest['configuration']) != fingerprint:
        raise ValueError('run manifest identity/configuration differs')
    configuration = manifest['configuration']
    if (manifest.get('test_protocol_fixed_before_training') is not True or
            configuration['primary_keeper'] != 'vision_keeper_v2:balanced:original_motion' or
            configuration['test_may_select_or_fit'] is not False):
        raise ValueError('frozen training/test scope differs')
    inputs = checked_inputs(manifest)
    if policy_hashes(RUN/'frozen/striker_v2') != configuration['base_policy_sha256']:
        raise ValueError('frozen baseline bytes changed')
    if (sha(RUN/'frozen/keeper_motion_v1.json') != configuration['motion_model_sha256'] or
            sha(RUN/'frozen/calibration_report.json') != configuration['calibration_report_sha256']):
        raise ValueError('frozen opponent/calibration bytes changed')
    state = envelope(RUN/'progress.json', fingerprint)
    training = read(RUN/'training_report.json')
    if (state['completed_updates'] != configuration['updates'] or
            state['training_transitions'] != configuration['updates']*configuration['workers']*configuration['ppo']['n_steps'] or
            training['fingerprint'] != fingerprint or training['state'] != state):
        raise ValueError('the fixed training budget is not complete or state/report differ')
    expected_updates = set(range(1, configuration['updates']+1))
    actual_updates = {int(path.name.removeprefix('update_'))
                      for path in (RUN/'checkpoints').glob('update_*')
                      if path.is_dir() and '.tmp' not in path.name}
    if actual_updates != expected_updates:
        raise ValueError('complete optimizer checkpoint sequence missing')
    for update in sorted(actual_updates):
        directory = RUN/'checkpoints'/('update_%04d' % update)
        resume = envelope(directory/'resume_state.json', fingerprint)
        if (resume['completed_updates'] != update or
                resume['checkpoint'] != directory.relative_to(RUN).as_posix() or
                resume['checkpoint_sha256'] != policy_hashes(directory) or
                set(resume.get('rng', {})) != {'python', 'numpy', 'torch'} or
                sha(directory/'obs_norm.npz') != configuration['base_policy_sha256']['obs_norm.npz']):
            raise ValueError('checkpoint resume/RNG/normalization identity differs')
        with ZipFile(directory/'model.zip') as model_zip:
            if not {'policy.pth', 'policy.optimizer.pth', 'data'} <= set(model_zip.namelist()):
                raise ValueError('PPO weights/optimizer missing from saved model')
    selected = envelope(RUN/'selection.json', fingerprint)
    validation_path = RUN/'evaluations/validation_selection/report.json'
    validation = read(validation_path)
    if (selected['test_used_for_selection'] is not False or selected['update'] < 1 or
            selected['policy'] != 'checkpoints/update_%04d' % selected['update'] or
            selected['policy_sha256'] != policy_hashes(RUN/selected['policy']) or
            selected['validation_report_sha256'] != sha(validation_path) or
            validation['split'] != 'validation'):
        raise ValueError('validation-only frozen selection differs')
    for rows in validation['records']['balanced'].values():
        if ({row['seed'] for row in rows} !=
                {configuration['split_bases']['validation']*1_000_000+i
                 for i in range(configuration['validation_episodes'])}):
            raise ValueError('validation seed namespace/count differs')
    trained_candidates = [candidate for candidate in selected['candidates'] if candidate['update'] > 0]
    best_trained = min(trained_candidates, key=lambda candidate: (
        -candidate['summary']['goal_rate'], candidate['summary']['striker_fall_rate'], candidate['update']))
    if best_trained['update'] != selected['update'] or selected['validation_summary'] != best_trained['summary']:
        raise ValueError('export candidate was not the preregistered best trained validation checkpoint')
    test = read(RUN/'test_report.json')
    if (test.get('run_fingerprint') != fingerprint or test.get('selection_sha256') != sha(RUN/'selection.json') or
            test.get('policy_sha256') != selected['policy_sha256'] or
            test.get('selected_update') != selected['update'] or
            test.get('model_frozen_before_test') is not True or
            test.get('test_used_for_selection') is not False or test.get('hardware_validated') is not False or
            test['split'] != 'test' or set(test['records']) != set(configuration['test_opponents'])):
        raise ValueError('completed blind-test proof differs')
    expected_seeds = {configuration['split_bases']['test']*1_000_000+i
                      for i in range(configuration['test_episodes'])}
    for mode, peers in test['records'].items():
        if set(peers) != {'v2', 'selected'}:
            raise ValueError('blind test must contain selected model and untouched v2')
        checked = {}
        for name, rows in peers.items():
            if len(rows) != len(expected_seeds) or {row['seed'] for row in rows} != expected_seeds:
                raise ValueError('test seeds/duplicates/count differ')
            checked[name] = summary(rows)
            published = test['summaries'][mode][name]
            if (checked[name]['counts']['sim_error'] or
                    published['episodes'] != len(rows) or
                    published['goal_rate'] != checked[name]['goal_rate'] or
                    published['save_rate'] != checked[name]['save_rate'] or
                    {key: published['counts'].get(key, 0) for key in RESULTS} != checked[name]['counts']):
                raise ValueError('blind-test counts/rates/error status differ')
            if any(row['environment']['keeper_mode'] != mode for row in rows):
                raise ValueError('episode opponent provenance differs')
        a, b = ({row['seed']: row for row in peers[name]} for name in ('selected', 'v2'))
        differences = [int(a[seed]['result'] == 'goal')-int(b[seed]['result'] == 'goal')
                       for seed in sorted(expected_seeds)]
        for seed in expected_seeds:
            if physical_reset(a[seed]) != physical_reset(b[seed]):
                raise ValueError('paired physical start differs')
        comparison = test['comparisons'][mode]
        lo, hi = comparison['goal_gain_ci95']
        if (comparison['episodes'] != len(expected_seeds) or
                not math.isclose(comparison['goal_gain'], sum(differences)/len(differences), abs_tol=1e-12) or
                comparison['candidate_only_goals'] != differences.count(1) or
                comparison['baseline_only_goals'] != differences.count(-1) or
                not all(math.isfinite(value) for value in (lo, hi)) or not -1 <= lo <= hi <= 1):
            raise ValueError('paired comparison counts/gain/interval differ')
    if (len(test['rows']) != len(expected_seeds)*len(configuration['test_opponents']) or
            any(row.get('children_collected') is not True for row in test['rows'])):
        raise ValueError('blind-test child cleanup proof missing')
    final_audit = read(RUN/'final_audit.json')
    audited_test = final_audit.get('test', {})
    if (final_audit.get('version') != 'striker_retraining_final_independent_audit_v1' or
            final_audit.get('phase') != 'training, validation and blind evaluation complete' or
            final_audit.get('evaluation_complete') is not True or
            final_audit.get('run_fingerprint') != fingerprint or
            final_audit.get('test_report_sha256') != sha(RUN/'test_report.json') or
            final_audit.get('selection_sha256') != sha(RUN/'selection.json') or
            audited_test.get('physical_cases') != 300 or audited_test.get('policy_duels') != 600 or
            audited_test.get('all_owned_native_children_measured_collected') != 1400 or
            audited_test.get('all_300_cache_envelopes_and_report_rows_exactly_match') is not True or
            audited_test.get('all_reset_engine_layout_fields_match_between_policies') is not True or
            audited_test.get('all_paired_goal_bootstrap_intervals_recomputed') is not True or
            final_audit.get('source_files_verified_unchanged') != 116 or
            final_audit.get('baseline_bhuman_files_verified_unchanged') != 559 or
            final_audit.get('checkpoint_initialization_rng', {}).get('selected_model_sha256') != selected['policy_sha256']['model.zip'] or
            final_audit.get('conclusion', {}).get('promote_retrained_policy') is not False):
        raise ValueError('complete independent 600-duel audit is missing or inconsistent')
    calibration_audit = read(ROOT/'runs/striker_retrain/calibration_audit.json')
    if calibration_audit['calibration_report_sha256'] != configuration['calibration_report_sha256']:
        raise ValueError('calibration audit identity differs')
    for name in SUPPORT:
        if not (ROOT/'runs/striker_retrain'/name).is_file():
            raise ValueError('support evidence missing: '+name)
    full_tests = (ROOT/'runs/striker_retrain/full_tests.log').read_text(encoding='utf-8')
    if not re.search(r'Ran 337 tests in .*?\r?\n\r?\nOK', full_tests):
        raise ValueError('full 337-test success evidence missing')
    return manifest, state, selected, validation, test, inputs


def archive_entries(inputs):
    entries = list(inputs)
    for path in sorted(RUN.rglob('*')):
        if not path.is_file() or any('.tmp' in component for component in path.relative_to(RUN).parts):
            continue
        entries.append({'path': path, 'archive': 'run/'+path.relative_to(RUN).as_posix(),
                        'sha256': sha(path), 'bytes': path.stat().st_size, 'role': 'complete_final_run'})
    # Include recovery wrappers/history and every actual run/resume log, also
    # when another explicitly recorded recovery added a new support file.
    support_paths = {ROOT/'runs/striker_retrain'/name for name in SUPPORT}
    support_paths.update(path for path in (ROOT/'runs/striker_retrain').iterdir()
                         if path.is_file() and path.suffix in ('.json', '.log', '.csv', '.py', '.txt')
                         and '.tmp' not in path.name and path.name != 'export_results.log')
    for path in sorted(support_paths):
        name = path.name
        entries.append({'path': path, 'archive': 'support/'+name,
                        'sha256': sha(path), 'bytes': path.stat().st_size, 'role': 'supporting_evidence'})
    if len({entry['archive'] for entry in entries}) != len(entries):
        raise ValueError('duplicate archive paths')
    return sorted(entries, key=lambda item: item['archive'])


def make_zip(entries, manifest, selected):
    package = REPORT/'complete_run.zip'
    temporary = package.with_name(package.name+'.tmp-'+str(os.getpid()))
    package_manifest = {
        'version': 'striker_visual_reproducibility_bundle_v1',
        'run_fingerprint': manifest['fingerprint'],
        'selection_sha256': sha(RUN/'selection.json'),
        'selected_policy_sha256': selected['policy_sha256'],
        'original_frozen_inputs': 116,
        'additional_runtime_dependency_note': 'onnxruntime.dll has an exported SHA; it was not in the original 116-input run fingerprint',
        'contains_entire_final_run': True,
        'fixed_zip_timestamp': '1980-01-01T00:00:00',
        'files': [{key: entry[key] for key in ('archive', 'sha256', 'bytes', 'role')} for entry in entries],
    }

    def add(archive, payload):
        info = ZipInfo(archive, date_time=(1980, 1, 1, 0, 0, 0))
        info.compress_type = ZIP_DEFLATED
        info.create_system = 3
        info.external_attr = 0o100644 << 16
        zip_file.writestr(info, payload, compress_type=ZIP_DEFLATED, compresslevel=9)

    REPORT.mkdir(parents=True, exist_ok=True)
    try:
        with ZipFile(temporary, 'w') as zip_file:
            for entry in entries:
                payload = entry['path'].read_bytes()
                if hashlib.sha256(payload).hexdigest() != entry['sha256']:
                    raise ValueError('artifact changed during export: '+str(entry['path']))
                add(entry['archive'], payload)
            add('artifact_manifest.json', json_bytes(package_manifest))
        with ZipFile(temporary) as zip_file:
            if zip_file.testzip() is not None:
                raise ValueError('archive CRC verification failed')
            for entry in entries:
                if hashlib.sha256(zip_file.read(entry['archive'])).hexdigest() != entry['sha256']:
                    raise ValueError('archived bytes checksum differs')
        if package.exists() and sha(package) != sha(temporary):
            raise ValueError('existing archive differs; export only the finalized evidence snapshot')
        os.replace(temporary, package)
    finally:
        if temporary.exists():
            temporary.unlink()
    return package_manifest, sha(package)


def pct(value):
    return ('%.2f' % (100*value)).replace('.', ',')+' %'


def pp(value):
    return ('%+.2f' % (100*value)).replace('.', ',')


def count(rows, name):
    return sum(row['result'] == name for row in rows)


def make_readme(manifest, state, selected, validation, test, package_sha):
    configuration = manifest['configuration']
    names = {'balanced': 'Nuestro v2 visual + balanced, movimiento original',
             'motion': 'Nuestro v2 visual + balanced + salto ajustado',
             'scripted': 'Nuestra FSM base con movimientos B-Human'}
    table = ['| Rival | Tirador | Penales | Goles | Atajadas | Fuera/corto | Timeout | Caída terminal |',
             '| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |']
    gains = ['| Rival | Ganancia de goles | IC95 pareado | Goles exclusivos nuevo / v2 |',
             '| --- | ---: | --- | ---: |']
    for mode in configuration['test_opponents']:
        for policy in ('v2', 'selected'):
            rows = test['records'][mode][policy]
            label = 'striker_v2 intacto' if policy == 'v2' else 'striker_visual_v3 experimental'
            table.append('| %s | %s | %d | %d (%s) | %d (%s) | %d | %d | %d |' % (
                names[mode], label, len(rows), count(rows, 'goal'), pct(count(rows, 'goal')/len(rows)),
                count(rows, 'save'), pct(count(rows, 'save')/len(rows)), count(rows, 'miss'),
                count(rows, 'timeout'), count(rows, 'striker_fall')+count(rows, 'keeper_fall')))
        comparison = test['comparisons'][mode]
        lo, hi = comparison['goal_gain_ci95']
        gains.append('| %s | %s puntos | [%s; %s] puntos | %d / %d |' % (
            names[mode], pp(comparison['goal_gain']), pp(lo), pp(hi),
            comparison['candidate_only_goals'], comparison['baseline_only_goals']))
    validation_table = ['| Política | Goles / 32 | Atajadas | Fallados | Timeout |',
                        '| --- | ---: | ---: | ---: | ---: |']
    for name, rows in validation['records']['balanced'].items():
        validation_table.append('| %s | %d / %d | %d | %d | %d |' % (
            name, count(rows, 'goal'), len(rows), count(rows, 'save'), count(rows, 'miss'), count(rows, 'timeout')))
    trained = next(candidate for candidate in selected['candidates'] if candidate['update'] == selected['update'])
    initialized = selected['initialization_diagnostic']
    learning = trained['vs_initialized']
    primary = test['comparisons']['balanced']
    lo, hi = primary['goal_gain_ci95']
    if lo > 0:
        conclusion = 'La prueba reservada muestra una ventaja de goles en esta muestra frente al portero principal. El piloto continúa como experimental.'
    elif hi < 0:
        conclusion = 'La prueba reservada muestra una regresión de goles frente al portero principal. Se conserva striker_v2 como referencia.'
    else:
        conclusion = 'El intervalo incluye cero: esta prueba no demuestra una ventaja de goles frente al portero principal. Se conserva striker_v2 como referencia.'
    regressed_secondary = [mode for mode in configuration['test_opponents']
                           if mode != 'balanced' and test['comparisons'][mode]['goal_gain_ci95'][1] < 0]
    if regressed_secondary:
        conclusion += ' Los duelos contra '+', '.join(names[mode] for mode in regressed_secondary)+\
                      ' muestran regresiones con intervalos completamente negativos.'
    promotion_note = ('La comparación de promoción en validación favoreció al modelo entrenado; permanece experimental en este piloto.'
                      if selected.get('validation_prefers_trained_over_v2') else
                      'La comparación de promoción en validación favoreció a striker_v2 intacto; se prueba el mejor checkpoint entrenado como candidato experimental, sin reemplazarlo.')
    reproduction = '''```powershell
# En una copia del repositorio: restaurar inputs/ respetando sus rutas,
# run/ en runs/striker_retrain/visual_v3, y support/ en runs/striker_retrain.
# Verificar los SHA de artifact_manifest.json antes de usar los archivos.
python tools/retrain_striker.py --output runs/striker_retrain/visual_v3 `
  --calibration-report runs/striker_retrain/visual_v3/frozen/calibration_report.json `
  --workers 6 --n-steps 128 --updates 24 --checkpoint-every 8 `
  --validation-episodes 32 --test-episodes 100 --learning-rate 0.0001 `
  --max-seconds 3600 --stage test --resume
```

Ese comando reutiliza los episodios de prueba ya guardados y comprueba identidad; no selecciona ni entrena otra política. Una repetición física nueva requiere otra carpeta y reproducir el protocolo completo, con las versiones y los inputs indicados en el manifiesto. Los checkpoints incluyen pesos y estado del optimizador; `resume_state.json` conserva RNG de Python/NumPy/Torch. Una reanudación de entrenamiento arranca episodios físicos nuevos con semillas sin usar, no restaura un estado exacto de MuJoCo. La selección ya congelada impide continuar entrenando dentro de esta corrida.
'''
    return '''# Tirador visual v3: piloto experimental contra nuestro portero v2 balanced

Se afinó tácticamente `striker_v2` contra nuestro portero visual v2 con `balanced` y movimientos B-Human originales. El checkpoint de la actualización **%(update)d** quedó seleccionado por **32 tiros de validación**, antes de ejecutar la prueba reservada. %(conclusion)s No se cambia la recomendación ni los archivos de `striker_v2` por el resultado de esta prueba.

## Prueba reservada: 100 tiros por rival y tirador

%(table)s

Cada pareja usa exactamente las mismas semillas y condiciones de inicio. Sólo `goal` es éxito: una atajada, un tiro fuera/corto, caída o timeout no cuentan como gol. “Fuera/corto” agrupa el resultado físico `miss`, sin contacto de bloqueo; “caída terminal” suma `striker_fall` y `keeper_fall`. Las caídas posteriores a una patada también están en las trazas, aunque el resultado del balón pueda ser gol o atajada. Hubo **cero errores de simulación** en esta evaluación y todos los hijos nativos fueron recogidos.

%(gains)s

Los intervalos son bootstrap pareado del indicador de gol, con todos los episodios programados en el denominador. Este ensayo compara políticas en la misma simulación y no establece convergencia ni rendimiento general fuera de estos tres rivales.

## Qué se entrenó y qué aporta la inicialización

Se completaron **%(updates)d actualizaciones PPO** de %(workers)d actores × %(n_steps)d pasos: **%(transitions)d transiciones optimizadas en la corrida**. El checkpoint seleccionado de la actualización %(update)d contiene **%(selected_transitions)d transiciones optimizadas nuevas**, además del entrenamiento heredado de v2. La política conserva `rl_obs_v1` (19 campos), `striker_action_v1` (4 decisiones: objetivo lateral, pie, potencia y disparo) y la normalización congelada de v2. No aprende trayectorias articulares: B-Human sigue ejecutando marcha y patada.

Antes de PPO se corrigió la saturación de la cabeza de acciones mediante `striker_policy_init_v2`, usando ocho tiros de calibración de semillas 90001. Las escalas por fila fueron `%(scales)s`; se conservaron los demás pesos y se reinició únicamente el estado Adam de esa cabeza. La calibración no consumió validación ni prueba. Por eso el progreso respecto a v2 debe distinguir **inicialización** de **aprendizaje PPO**.

%(validation_table)s

La inicialización sola obtuvo %(init_goals)d/32 goles y no era elegible como candidato entrenado. El checkpoint elegido obtuvo %(selected_validation_goals)d/32: frente a la inicialización, su cambio fue %(learning_gain)s puntos, IC95 [%(learning_lo)s; %(learning_hi)s]. La selección examinó las actualizaciones 8, 16 y 24, favoreciendo más goles, después menos caídas y después la actualización más temprana. La prueba final no eligió ni ajustó pesos.

La prueba reservada compara el efecto completo de inicialización y entrenamiento con v2. No prueba la inicialización sola frente a los tres rivales; por tanto, una regresión en esos duelos no puede atribuirse únicamente a las actualizaciones PPO.

%(promotion_note)s

La recompensa nueva `striker_visual_reward_v2` cobra −0,02 por decisión, da +10 al gol y −10 a cualquier otro resultado terminal, incluido timeout. El límite observado de 28 segundos termina el episodio y no permite bootstrap hacia un futuro posterior al penal.

## Interrupción y recuperación

La primera sesión sufrió **un error de simulación durante la recolección**, después de la actualización 4. Su mensaje genérico no conservó la causa ni la semilla del episodio fallido; no se afirma que el entrenamiento haya tenido cero errores. El rollout incompleto no se optimizó. Se conservaron pesos, optimizador y RNG del último checkpoint completo, y se reservaron **774 índices de semillas** (70–843) para evitar reutilizar los posibles episodios de esa recolección descartada. La reanudación empezó desde 91001000844, sin cambiar las 116 fuentes/configuración congeladas.

El historial, los logs originales y de reanudación, el wrapper diagnóstico y la [auditoría de recuperación](recovery_audit.json) están preservados en el ZIP y en [failure_history.json](failure_history.json). Por esta interrupción, las %(transitions)d transiciones optimizadas no son un conteo de todo el trabajo físico ejecutado: los episodios/transiciones de la recolección descartada no se conocen exactamente.

## Percepción y alcance

El portero principal recibe RGB renderizado, detección de balón y transformaciones derivadas de sus propios encoders/IMU/FSR y odometría estimada. Conserva la predicción v2 y la selección `balanced`; no usa una orientación ideal del rival. El tirador recibe datos privilegiados de la escena con `PerceptionNoise v1`, como v2: su percepción aún no equivale a cámaras reales. El rival secundario carga el perfil congelado `keeper_motion_v1` y acelera un 15 %% las fases activas del salto. La FSM base es nuestra implementación con movimientos B-Human, **no el comportamiento oficial completo de B-Human**.

Todo ocurrió en MuJoCo con raíces libres, servos y contactos. Los sensores propios simulados son ideales y la física se pausa durante inferencia RGB. **No hubo ejecución ni validación en un NAO físico.**

## Evidencia y reproducción

- [Prueba completa](test_report.json), [selección congelada](selection.json), [validación](validation_report.json), [entrenamiento](training_report.json) y [manifiesto de corrida](run_manifest.json).
- [Inicialización](initialization_report.json), [auditoría de calibración](calibration_audit.json), [paridad del entorno en dos semillas externas](env_parity.json), [auditoría independiente](final_audit.json) y [337 pruebas aprobadas](full_tests.log).
- [Resumen de resultados](results.json), [modelo exportado](../../../../models/rl/striker_visual_v3/README.md) y [todos los SHA exportados](artifacts.json).
- [ZIP reproducible de toda la corrida](complete_run.zip): 24 checkpoints con optimizador y RNG, pesos originales, calibración, rival congelado, progreso, logs, evaluaciones y todos los 116 inputs congelados de fuentes/modelos/runtime/mallas. Incluye adicionalmente `onnxruntime.dll`, con SHA propio, porque esa dependencia no estaba en la clave original de 116 inputs.

Fingerprint de corrida: `%(fingerprint)s`.

SHA256 del ZIP: `%(package_sha)s`.

%(reproduction)s
''' % {'update': selected['update'], 'conclusion': conclusion,
       'table': '\n'.join(table), 'gains': '\n'.join(gains),
       'updates': state['completed_updates'], 'workers': configuration['workers'],
       'n_steps': configuration['ppo']['n_steps'], 'transitions': state['training_transitions'],
       'selected_transitions': selected['update']*configuration['workers']*configuration['ppo']['n_steps'],
       'scales': configuration['head_row_scales'], 'validation_table': '\n'.join(validation_table),
       'init_goals': initialized['summary']['counts'].get('goal', 0),
       'selected_validation_goals': selected['validation_summary']['counts'].get('goal', 0),
       'promotion_note': promotion_note,
       'learning_gain': pp(learning['goal_gain']), 'learning_lo': pp(learning['goal_gain_ci95'][0]),
       'learning_hi': pp(learning['goal_gain_ci95'][1]),
       'fingerprint': manifest['fingerprint'], 'package_sha': package_sha,
       'reproduction': reproduction}


def export():
    manifest, state, selected, validation, test, inputs = validate_completed_run()
    entries = archive_entries(inputs)
    selected_directory = RUN/selected['policy']
    for name in POLICY_FILES:
        immutable_copy(selected_directory/name, MODEL/name)
    if policy_hashes(MODEL) != selected['policy_sha256']:
        raise ValueError('exported selected-policy bytes differ')
    for name in STANDALONE:
        immutable_copy(RUN/name, REPORT/name)
    for path in sorted(RUN.glob('*audit*.json')):
        immutable_copy(path, REPORT/path.name)
    immutable_copy(RUN/'evaluations/validation_selection/report.json', REPORT/'validation_report.json')
    for name in ('calibration_audit.json', 'env_parity.json', 'warmstart_audit.json',
                 'design_audit.json', 'full_tests.log'):
        immutable_copy(ROOT/'runs/striker_retrain'/name, REPORT/name)
    package_manifest, package_sha = make_zip(entries, manifest, selected)
    results = {'version': 'striker_visual_results_export_v1',
               'run_fingerprint': manifest['fingerprint'], 'status': 'experimental',
               'promoted': False, 'selected_update': selected['update'],
               'test_used_for_selection': False, 'hardware_validated': False,
               'initialization': manifest['configuration']['initialization'],
               'training_transitions': state['training_transitions'],
               'selected_checkpoint_training_transitions': selected['update']*manifest['configuration']['workers']*manifest['configuration']['ppo']['n_steps'],
               'training_transitions_scope': 'completed optimized PPO transitions; excludes discarded physical rollout work of unknown size',
               'training_failure_history_sha256': sha(RUN/'failure_history.json'),
               'zero_training_errors_claimed': False,
               'validation_summary': selected['validation_summary'],
               'validation_promotion_candidate': selected['promotion_candidate'],
               'validation_prefers_trained_over_v2': selected['validation_prefers_trained_over_v2'],
               'initialization_diagnostic': selected['initialization_diagnostic'],
               'summaries': test['summaries'], 'paired_comparisons': test['comparisons'],
               'selected_policy_sha256': selected['policy_sha256'],
               'selection_sha256': sha(RUN/'selection.json'),
               'test_report_sha256': sha(RUN/'test_report.json'),
               'resume_state_sha256': sha(selected_directory/'resume_state.json'),
               'complete_run_zip_sha256': package_sha,
               'original_frozen_input_count': 116,
               'original_frozen_input_bytes': sum(item['bytes'] for item in inputs if item['role'] == 'original_frozen_input'),
               'zip_entry_count': len(package_manifest['files'])+1,
               'limitations': manifest['limitations']}
    atomic_write(REPORT/'results.json', json_bytes(results))
    atomic_write(REPORT/'README.md', make_readme(manifest, state, selected, validation, test, package_sha).encode('utf-8'))
    model_readme = '''# striker_visual_v3 — experimental

Checkpoint PPO de la actualización %d, elegido sólo con validación contra nuestro portero v2 visual + balanced y movimiento original. Se exportan `model.zip`, `obs_norm.npz` y `config.json` sin cambiar un byte; los pesos y el optimizador quedan en el modelo.

Compatible con observación `rl_obs_v1` de 19 campos, acción táctica de 4 componentes e historia 1. Conserva normalización congelada de striker_v2. Recompensa nueva: `striker_visual_reward_v2`; inicialización calibrada: `striker_policy_init_v2`.

Estado experimental, sin promoción del modelo original y sin validación física en NAO. [Resultados, limitaciones y evidencia](../../../docs/validation/rl/striker_visual_v3/README.md).

SHA256 del checkpoint seleccionado:

```json
%s
```
''' % (selected['update'], json.dumps(selected['policy_sha256'], indent=2))
    atomic_write(MODEL/'README.md', model_readme.encode('utf-8'))
    artifacts = {'version': 'striker_visual_artifact_checksums_v1',
                 'run_fingerprint': manifest['fingerprint'],
                 'model_files': {path.relative_to(ROOT).as_posix(): sha(path)
                                 for path in sorted(MODEL.rglob('*')) if path.is_file()},
                 'report_files': {path.relative_to(REPORT).as_posix(): sha(path)
                                  for path in sorted(REPORT.rglob('*'))
                                  if path.is_file() and path.name != 'artifacts.json' and '.tmp' not in path.name}}
    atomic_write(REPORT/'artifacts.json', json_bytes(artifacts))
    path = ROOT/'models/rl/manifest.json'
    existing = read(path)
    entry = {'rol': 'striker', 'tipo': 'afinamiento PPO táctico contra nuestro portero visual v2 balanced',
             'archivo': 'models/rl/striker_visual_v3', 'historia': 1,
             'observation': 'rl_obs_v1', 'action': 'striker_action_v1',
             'reward': 'striker_visual_reward_v2', 'initialization': 'striker_policy_init_v2',
             'estado': 'experimental; evaluación reservada, sin promoción de striker_v2 ni validación hardware',
             'entrenamiento': {'updates': state['completed_updates'],
                              'optimized_transitions': state['training_transitions'],
                              'selected_checkpoint_optimized_transitions': selected['update']*manifest['configuration']['workers']*manifest['configuration']['ppo']['n_steps'],
                              'known_failed_collectors': 1, 'zero_training_errors_claimed': False,
                              'opponent': manifest['configuration']['primary_keeper'],
                              'seed_base': manifest['configuration']['split_bases']['train']},
             'validacion': {'episodes': manifest['configuration']['validation_episodes'],
                            'selected_update': selected['update'],
                            'selected_summary': selected['validation_summary'],
                            'v2_summary': validation['summaries']['balanced']['v2'],
                            'promotion_prefers_trained_over_v2': selected['validation_prefers_trained_over_v2'],
                            'test_used_for_selection': False},
             'evaluacion': {'episodes_per_opponent': manifest['configuration']['test_episodes'],
                            'summaries': test['summaries'], 'paired_comparisons': test['comparisons'],
                            'hardware_validated': False},
             'sha256': selected['policy_sha256'], 'run_fingerprint': manifest['fingerprint'],
             'report': 'docs/validation/rl/striker_visual_v3/test_report.json',
             'reproducibility_bundle_sha256': package_sha}
    if 'striker_visual_v3' in existing and existing['striker_visual_v3'] != entry:
        raise ValueError('existing model manifest entry differs')
    existing['striker_visual_v3'] = entry
    atomic_write(path, json_bytes(existing))
    # Ensure no read-only input changed between validation and completion.
    checked_inputs(manifest)
    if sha(RUN/'test_report.json') != results['test_report_sha256']:
        raise ValueError('completed test changed during export')
    print(json.dumps({'model': str(MODEL), 'report': str(REPORT),
                      'selected_update': selected['update'], 'zip_sha256': package_sha,
                      'zip_bytes': (REPORT/'complete_run.zip').stat().st_size,
                      'run_fingerprint': manifest['fingerprint']}, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--export', action='store_true',
                        help='perform final export after explicit root-agent authorization')
    args = parser.parse_args()
    if not args.export:
        parser.error('--export is required; wait for the root agent to authorize the finalized snapshot')
    export()
