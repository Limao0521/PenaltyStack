"""Read-only check of the staged experiment, including checkout byte identity."""
from pathlib import Path
import hashlib
import json
import subprocess
from zipfile import ZipFile


ROOT = Path(__file__).resolve().parents[2]
REPORT = ROOT / 'docs/validation/rl/striker_visual_v3'
RUN = ROOT / 'runs/striker_retrain/visual_v3'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.run(['git', *args], cwd=ROOT, capture_output=True, check=True).stdout


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def index(path):
    return git('show', ':' + path)


def main():
    manifest = read(RUN / 'run_manifest.json')
    artifacts = read(REPORT / 'artifacts.json')
    checked = 0
    for path, expected in artifacts['model_files'].items():
        assert sha(index(path)) == expected, ('model index checksum', path)
        assert sha((ROOT / path).read_bytes()) == expected
        checked += 1
    for relative, expected in artifacts['report_files'].items():
        path = (REPORT / relative).relative_to(ROOT).as_posix()
        assert sha(index(path)) == expected, ('report index checksum', path)
        assert sha((ROOT / path).read_bytes()) == expected
        checked += 1
    artifacts_path = (REPORT / 'artifacts.json').relative_to(ROOT).as_posix()
    assert index(artifacts_path) == (ROOT / artifacts_path).read_bytes()
    audit = read(REPORT / 'final_audit.json')
    assert audit['run_fingerprint'] == manifest['fingerprint']
    assert 'progress' not in audit.get('phase', '').lower(), ('incomplete audit', audit.get('phase'))
    frozen = manifest['configuration']['source_hashes']
    tracked = set(git('ls-files', '-z').decode().split('\0'))
    paths = sorted(set(frozen) & tracked)
    attributes = {}
    for line in git('check-attr', 'text', 'eol', '--', *paths).decode().splitlines():
        path, attribute, value = line.split(': ', 2)
        attributes.setdefault(path, {})[attribute] = value
    with ZipFile(REPORT / 'complete_run.zip') as archive:
        for path, expected in frozen.items():
            assert sha(archive.read('inputs/' + path.replace('\\', '/'))) == expected, ('zip input checksum', path)
            assert sha((ROOT / path).read_bytes()) == expected, ('workspace frozen checksum', path)
            if path in tracked:
                data = index(path)
                attr = attributes[path]
                if attr.get('text') != 'unset' and attr.get('eol') == 'crlf':
                    data = data.replace(b'\r\n', b'\n').replace(b'\n', b'\r\n')
                assert sha(data) == expected, ('reconstructed checkout checksum', path, attr)
        assert archive.testzip() is None
    old = json.loads(git('show', 'HEAD:models/rl/manifest.json'))
    new = json.loads(index('models/rl/manifest.json'))
    assert set(new) == set(old) | {'striker_visual_v3'}
    assert all(new[name] == entry for name, entry in old.items()), 'existing manifest entry modified'
    assert new['striker_v2']['estado'] == 'recomendado'
    assert new['striker_visual_v3']['sha256'] == read(REPORT / 'results.json')['selected_policy_sha256']
    changed = git('diff', '--cached', '--name-only').decode().splitlines()
    allowed_files = {
        '.gitattributes', '.ai/HANDOFF.md', 'docs/RL.md', 'docs/RESULTADOS_RL.md',
        'docs/ENTRENAMIENTO_TIRADOR_VISUAL.md', 'models/rl/manifest.json',
        'penalty/rl/striker_visual_env.py', 'penalty/rl/striker_calibration.py',
        'penalty/rl/striker_retraining.py', 'tools/calibrate_striker_retraining.py',
        'tools/retrain_striker.py', 'tests/test_striker_visual_env.py',
        'tests/test_striker_calibration.py', 'tests/test_striker_retraining.py',
    }
    assert all(path in allowed_files or path.startswith('models/rl/striker_visual_v3/')
               or path.startswith('docs/validation/rl/striker_visual_v3/') for path in changed), changed
    print(json.dumps({'artifact_index_files_verified': checked + 1,
                      'frozen_inputs_verified_in_zip': len(frozen),
                      'tracked_input_checkout_hashes_verified': len(paths),
                      'old_manifest_entries_unchanged': len(old),
                      'staged_files': len(changed), 'recommended_striker': 'striker_v2'}, indent=2))


if __name__ == '__main__':
    main()
